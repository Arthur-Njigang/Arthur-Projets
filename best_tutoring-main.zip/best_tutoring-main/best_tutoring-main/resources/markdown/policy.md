# Politique de confidentialité

Modifiez ce fichier pour définir la politique de confidentialité de votre application.
