<div class="max-w-7xl w-full h-full bg-white dark:bg-gray-800 text-left">
    <div class="h-full flex flex-col">
        <div class="flex items-start">
            <img class="w-20 h-20 mb-3 rounded-full shadow-lg  bg-gray-100 object-cover object-center flex-shrink-0 mr-4"
                src="{{ $profile->avatarUrl }}" alt="{{ $profile->user->name }}" />
            <div class="flex-grow leading-tight pt-0 text-left">
                <h5 class="mb-0 text-xl font-medium text-gray-900 dark:text-white">
                    {{ $profile->user->name }}</h5>
                <div class="flex justify-between items-center">
                    <div>
                        <span class="text text-gray-500 dark:text-gray-400 block capitalize">
                            {{ $profile->discipline->name }}
                        </span>
                        <span class="text-sm text-gray-500 dark:text-gray-500 block">
                            {{ $profile->user->edu_level }}
                        </span>
                    </div>
                    <span
                        class="bg-blue-100 text-blue-700 text-sm font-semibold mr-2 px-2.5 py-0.5 rounded-full dark:bg-blue-900 dark:text-blue-300">
                        <x-money :amount="$profile->hourly_rate" currency="EUR" convert />/heure
                    </span>
                </div>
            </div>
        </div>
        @if ($profile->remote)
            <div class="flex items-center justify-end px-4 text-primary-500">
                <span title="{{ __('remote_course') }}"
                    class="relative inline-flex items-center p-1.5 text-sm font-medium text-center text-white bg-primary-500 rounded-full hover:bg-primary-600 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"
                        title="{{ __('remote_course') }}">
                        <path fill-rule="evenodd"
                            d="M3 5a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2h-2.22l.123.489.804.804A1 1 0 0113 18H7a1 1 0 01-.707-1.707l.804-.804L7.22 15H5a2 2 0 01-2-2V5zm5.771 7H5V5h10v7H8.771z"
                            clip-rule="evenodd" />
                    </svg>
                </span>
            </div>
        @endif
        <h4 class="uppercase text-gray-800 font-semibold text-sm py-2">
            {{ __('time_slots') }}
        </h4>
        @if ($profile->timeSlots->isEmpty())
            <div class="text-gray-500 dark:text-gray-400">
                {{ __('no_time_slots') }}
            </div>
        @endif
        @foreach ($profile->timeSlots as $slot)
            <p class="py-1 text-left">
                <span class="font-semibold text-gray-800">
                    {{ $slot->weekday->name }},
                </span>
                <span class="font-normal text-gray-600">
                    {{ $slot->start_time->translatedFormat('G\hi') }} -
                    {{ $slot->end_time->translatedFormat('G\hi') }}
                </span>
            </p>
        @endforeach

        <div class="" id="accordion-collapse-{{ $profile->id }}" data-accordion="collapse">
            <button type="button" id="accordion-collapse-{{ $profile->id }}-heading-1"
                class="flex items-center justify-between w-fit pt-4 pb-2 font-medium text-left text-gray-500 bg-transparent"
                data-accordion-target="#accordion-collapse-{{ $profile->id }}-body-1"
                aria-expanded="{{ $detailing }}" aria-controls="accordion-collapse-{{ $profile->id }}-body-1"
                wire:click="details">
                <span class="inline-block pr-2">{{ __('details') }}</span>
                @if ($detailing)
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 15l7-7 7 7" />
                    </svg>
                @else
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                @endif
            </button>
            <div id="accordion-collapse-{{ $profile->id }}-body-1" class="{{ $detailing ? '' : 'hidden' }} pb-6"
                aria-labelledby="accordion-collapse-{{ $profile->id }}-heading-1">
                <svg wire:loading.block wire:target="details" aria-hidden="{{ !$detailing }}" role="status"
                    class="block w-4 h-4 m-auto text-primary animate-spin" viewBox="0 0 100 101" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                        fill="#E5E7EB" />
                    <path
                        d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                        fill="currentColor" />
                </svg>
                <div class="p-0 flex dark:bg-gray-900" wire:loading.remove wire:target="details">
                    <div class="order-1 w-3/4 pt-10 space-y-6">
                        @foreach ($profile->ratings->take(10) as $rating)
                            <article>
                                <div class="flex items-center mb-4 space-x-4">
                                    <img class="w-10 h-10 rounded-full" src="{{ $rating->user->profile_photo_url }}"
                                        alt="{{ $rating->user->name }}">
                                    <div class="space-y-1 font-medium dark:text-white">
                                        <p>
                                            {{ $rating->user->name }}
                                        </p>
                                    </div>
                                </div>
                                <x-rating-item :rating="$rating->score" />
                                <footer class="mb-3 text-sm text-gray-500 dark:text-gray-400">
                                    <p> {{ __('reviewed_on') }}
                                        <time datetime="2017-03-03 19:00">
                                            {{ $rating->updated_at->translatedFormat('d F, Y') }}
                                        </time>
                                    </p>
                                </footer>
                                @if ($rating->comment)
                                    <p class="mb-0 text-base text-gray-700 dark:text-gray-400">
                                        {{ $rating->comment }}
                                    </p>
                                @endif
                            </article>
                        @endforeach
                    </div>
                    <div class="order-2 w-1/4 px-2 flex justify-end">
                        <div class="h-full w-fit bg-white rounded-3xl">
                            <p class="font-heading font-medium">
                                <span class="text-4xl">{{ (int) $profile->rating }}</span>
                                <span class="text-gray-300">/5</span>
                            </p>
                            <x-rating-item :rating="(int) $profile->rating" />
                            <p class="text-sm text-gray-400 font-medium">
                                {{ trans_choice('reviews_count', $profile->ratings_count) }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @auth
            <div class="flex justify-end mt-auto">
                <button @click="$openModal('book-modal-{{ $profile->id }}')" wire:click="open"
                    class="text-white bg-primary-500 hover:bg-primary-600 focus:ring-4 focus:outline-none focus:ring-primary-200 font-medium rounded-lg text-sm px-4 py-2.5 text-center inline-flex items-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-yellow-800"
                    type="button">
                    {{ __('book') }}
                </button>
                <x-modal.card align="center" max-width="lg" name="book-modal-{{ $profile->id }}"
                    title="{{ __('booking_details') }}" blur wire:model.defer="cardModal">
                    <form class="w-full py-4 px-4" wire:submit.prevent="book">
                        {{ $this->form }}
                        @if (session()->has('error'))
                            <div class="flex  py-6 text-sm text-red-600 dark:bg-gray-800 dark:text-red-400"
                                role="alert">
                                <svg xmlns="http://www.w3.org/2000/svg" class="flex-shrink-0 inline w-5 h-5 mr-3"
                                    fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                <div>
                                    <span class="font-medium">
                                        {{ session('error') }}
                                    </span>
                                </div>
                            </div>
                        @endif

                        <div class="flex justify-end">
                            <button type="submit"
                                class="mt-4 text-white bg-primary-500 hover:bg-primary-600 focus:ring-4 focus:outline-none focus:ring-primary-200 font-medium rounded-lg text-sm px-3 py-2 text-center inline-flex items-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">
                                <svg wire:loading.inline aria-hidden="true" role="status"
                                    class="w-4 h-4 mr-3 text-white animate-spin" viewBox="0 0 100 101" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                        fill="#E5E7EB" />
                                    <path
                                        d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                        fill="currentColor" />
                                </svg>
                                {{ __('confirm') }}
                            </button>
                        </div>
                    </form>
                </x-modal.card>
            </div>
        @endauth
    </div>
</div>
