<div>
    <x-form-section submit="save">
        <x-slot name="title">
            {{ __('personal_information') }}
        </x-slot>

        <x-slot name="description">
            {{ __('Update your account\'s personal information,they will be kept secret and disclosed only at your discretion.') }}
        </x-slot>

        <x-slot name="form">
            <div class="w-full col-span-3">
                {{ $this->form }}
            </div>
        </x-slot>

        <x-slot name="actions">
            <x-action-message class="mr-3" on="saved">
                {{ __('Saved.') }}
            </x-action-message>

            <x-app-button wire:loading.attr="disabled">
                {{ __('save') }}
            </x-app-button>
        </x-slot>
    </x-form-section>
</div>
