<div class="container">
    {{ $this->table }}
</div>
