<div class="max-w-7xl mx-auto">
    <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-xl sm:rounded-lg py-4 px-4">
        <div class="flex justify-end">
            <button id="dropdownButton-{{ $profile->id }}" data-dropdown-toggle="dropdown-{{ $profile->id }}"
                class="inline-block text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 focus:ring-4 focus:outline-none focus:ring-gray-200 dark:focus:ring-gray-700 rounded-lg text-sm p-1.5"
                type="button">
                <span class="sr-only">Open dropdown</span>
                <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z">
                    </path>
                </svg>
            </button>
            <!-- Dropdown menu -->
            <div id="dropdown-{{ $profile->id }}"
                class="z-10 hidden text-base list-none bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
                <ul class="py-2" aria-labelledby="dropdownButton-{{ $profile->id }}">
                    <li>
                        <a href="{{ route('edit-profile', ['id' => $profile->id]) }}" type="button"
                            class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">
                            {{ __('edit') }}
                        </a>
                    </li>
                    <li>
                        <button data-modal-target="defaultModal-{{ $profile->id }}"
                            data-modal-toggle="defaultModal-{{ $profile->id }}" type="button"
                            class="w-full block text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">
                            {{ __('delete') }}
                        </button>
                    </li>
                </ul>
            </div>
        </div>
        <div class="flex flex-wrap px-4">
            <div class="lg:w-1/2 md:w-1/2 w-full">
                <div class="h-full border-gray-200 border-r pr-4">
                    <div class="flex items-start">
                        <img class="w-24 h-24 mb-3 rounded-full shadow-lg  bg-gray-100 object-cover object-center flex-shrink-0 mr-4"
                            src="{{ $profile->avatarUrl }}" alt="{{ $profile->user->name }}" />
                        <div class="flex-grow leading-tight pt-4">
                            <h5 class="mb-0 text-xl font-medium text-gray-900 dark:text-white">
                                {{ $profile->user->name }}</h5>
                            <div class="flex justify-between items-center">
                                <div>
                                    <span class="text text-gray-500 dark:text-gray-400 block capitalize">
                                        {{ $profile->discipline->name }}
                                    </span>
                                    <span class="text-sm text-gray-500 dark:text-gray-500 block">
                                        {{ $profile->user->edu_level }}
                                    </span>
                                </div>
                                <span
                                    class="bg-blue-100 text-blue-700 text-sm font-semibold mr-2 px-2.5 py-0.5 rounded-full dark:bg-purple-900 dark:text-purple-300">
                                    <x-money :amount="$profile->hourly_rate" currency="EUR" convert />/heure
                                </span>
                            </div>
                        </div>
                    </div>
                    @if ($profile->remote)
                        <div class="flex items-center justify-end px-4 text-primary-500">
                            <span title="{{ __('remote_course') }}"
                                class="relative inline-flex items-center p-1.5 text-sm font-medium text-center text-white bg-primary-500 rounded-full hover:bg-primary-600 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                    fill="currentColor" title="{{ __('remote_course') }}">
                                    <path fill-rule="evenodd"
                                        d="M3 5a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2h-2.22l.123.489.804.804A1 1 0 0113 18H7a1 1 0 01-.707-1.707l.804-.804L7.22 15H5a2 2 0 01-2-2V5zm5.771 7H5V5h10v7H8.771z"
                                        clip-rule="evenodd" />
                                </svg>
                            </span>
                        </div>
                    @endif
                    <h4 class="uppercase text-gray-800 font-semibold text-sm py-2">
                        {{ __('time_slots') }}
                    </h4>
                    @if ($profile->timeSlots->isEmpty())
                        <div class="text-gray-500 dark:text-gray-400">
                            {{ __('no_time_slots') }}
                        </div>
                    @endif
                    @foreach ($profile->timeSlots as $slot)
                        <p class="py-1">
                            <span class="font-semibold text-gray-800">
                                {{ $slot->weekday->name }},
                            </span>
                            <span class="font-normal text-gray-600">
                                {{-- {{ $start }} - {{ $end }} --}}
                                {{ $slot->start_time->translatedFormat('G\hi') }} -
                                {{ $slot->end_time->translatedFormat('G\hi') }}
                            </span>
                        </p>
                    @endforeach
                    <h4 class="uppercase text-gray-800 font-semibold text-sm pt-10 pb-2">
                        {{ __('cv') }}
                    </h4>
                    @php
                        $cv = $profile->getFirstMedia('cv');
                    @endphp
                    <div class="">
                        @if ($cv)
                            <a href="{{ $cv->getUrl() }}"
                                class="text-blue-500 hover:text-blue-700 duration-200 inline-flex flex-col items-start mb-2">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    stroke-width="1.5" stroke="currentColor"
                                    class="w-10 h-10 hover:bg-gray-200 rounded-full p-2 duration-200">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                                </svg>
                                <span class="block text-xs font-medium text-gray-600">
                                    {{ $cv->name }}
                                </span>
                            </a>
                        @else
                            <div class="text-gray-500 dark:text-gray-400">
                                {{ __('no_cv') }}
                            </div>
                        @endif
                    </div>
                </div>
            </div>
            <div class="lg:w-1/2 md:w-1/2 w-full">
                <div class="h-full border-gray-200 pl-4">
                    <h4 class="uppercase text-gray-800 font-bold text-sm mb-4">
                        {{ __('experiences') }}
                    </h4>
                    @if ($profile->experiences->isEmpty())
                        <div class="text-gray-500 dark:text-gray-400">
                            {{ __('no_experience') }}
                        </div>
                    @endif
                    @foreach ($profile->experiences as $experience)
                        <div class="">
                            <h2 class="text-lg font-medium title-font text-gray-800">
                                {{ $experience->title }}
                            </h2>
                            <span class="text-sm text-gray-500 block capitalize">
                                {{ $experience->start_date->translatedFormat('d, M. Y') }} -
                                {{ $experience->end_date?->translatedFormat('d, M. Y') ?? 'Présent' }}
                            </span>
                            <span class="text-xs uppercase font-bold text-gray-800 block">
                                {{ $experience->type->value }}
                            </span>
                            <p class="leading-relaxed text-base text-gray-700 py-2">
                                {{ Illuminate\Mail\Markdown::parse($experience->description) }}
                            </p>
                            <h3 class="text-xs uppercase font-extrabold title-font mb-2 text-gray-900">
                                {{ __('attachments') }}
                            </h3>
                            <div class="space-x-4">
                                @if ($experience->attachments->isEmpty())
                                    <div class="text-gray-500 dark:text-gray-400 text-sm">
                                        {{ __('no_attachment') }}
                                    </div>
                                @endif
                                @foreach ($experience->attachments as $attachment)
                                    <a href="{{ $attachment->getUrl() }}"
                                        class="text-blue-500 hover:text-blue-700 duration-200 inline-flex flex-col items-start mb-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor"
                                            class="w-10 h-10 hover:bg-gray-200 rounded-full p-2 duration-200">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                                        </svg>
                                        <span class="block text-xs font-medium text-gray-600">
                                            {{ $attachment->name }}
                                        </span>
                                    </a>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="w-full flex justify-end">
                <span class="{{ $profile->statusColor }} text-sm font-medium px-2.5 py-0.5 rounded-full">
                    {{ $profile->statusText }}
                </span>
            </div>
        </div>

    </div>
    <!-- Main modal -->
    <div id="defaultModal-{{ $profile->id }}" tabindex="-1" aria-hidden="true"
        class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative w-full max-w-2xl max-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <div class="flex items-start justify-between p-4 border-b rounded-t dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                        Supprimer le profil
                    </h3>
                    <button type="button"
                        class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white"
                        data-modal-hide="defaultModal-{{ $profile->id }}">
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <div class="p-6 space-y-6">
                    <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                        Cette opération est irreversible, êtes-vous sûr de vouloir supprimer ce profil ?
                    </p>
                </div>
                <!-- Modal footer -->
                <div
                    class="flex items-center justify-end p-6 space-x-2 border-t border-gray-200 rounded-b dark:border-gray-600">
                    <button data-modal-hide="defaultModal-{{ $profile->id }}" type="button"
                        class="text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-primary-300 rounded-lg border border-gray-200 text-sm font-medium px-3 py-2 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">
                        Annuler
                    </button>
                    <button type="button" x-data="{ spinning: false }" @click="spinning = true"
                        wire:click="deleteProfile"
                        class="text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-3 py-2 text-center inline-flex items-center dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800">
                        <svg x-show="spinning" aria-hidden="true" role="status"
                            class="inline w-4 h-4 mr-3 text-white animate-spin" viewBox="0 0 100 101" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                fill="#E5E7EB" />
                            <path
                                d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                fill="currentColor" />
                        </svg>
                        {{ __('delete') }}
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
