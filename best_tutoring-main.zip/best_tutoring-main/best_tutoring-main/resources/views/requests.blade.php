@php
    use App\Enums\RequestStatus;
    use App\Enums\Roles;
@endphp
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('tutoring_requests') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div
                class="w-full bg-white border border-gray-200 rounded-lg dark:bg-gray-800 dark:border-gray-700 overflow-hidden shadow-xl sm:rounded-lg">
                <ul class="flex flex-wrap text-sm font-medium text-center text-gray-500 border-b border-gray-200 rounded-t-lg bg-gray-50 dark:border-gray-700 dark:text-gray-400 dark:bg-gray-800"
                    id="defaultTab" data-tabs-toggle="#defaultTabContent" role="tablist">
                    @role(Roles::Student->value)
                        <li class="mr-2">
                            <button id="sent-tab" data-tabs-target="#sent" type="button" role="tab"
                                aria-controls="sent" aria-selected="true"
                                class="aria-selected:text-primary-600  aria-selected:dark:bg-gray-800 aria-selected:dark:text-primary-500 inline-block p-4 rounded-tl-lg hover:bg-gray-100 dark:bg-gray-800 dark:hover:bg-gray-700">
                                {{ __('sent') }}
                            </button>
                        </li>
                    @endrole


                    @role(Roles::Tutor->value)
                        <li class="mr-2">
                            <button id="received-tab" data-tabs-target="#received" type="button" role="tab"
                                aria-controls="received" aria-selected="false"
                                class="aria-selected:text-primary-600  aria-selected:dark:bg-gray-800 aria-selected:dark:text-primary-500 inline-block p-4 hover:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300">
                                {{ __('received') }}
                            </button>
                        </li>
                    @endrole

                </ul>
                <div id="defaultTabContent">
                    @role(Roles::Student->value)
                        <div class="hidden p-4 bg-white rounded-lg md:p-8 dark:bg-gray-800" id="sent" role="tabpanel"
                            aria-labelledby="sent-tab">
                            <div class="flex flex-wrap -m-2">
                                @php
                                    $sentRequests = auth()
                                        ->user()
                                        ->sentRequests()
                                        ->where('end_date', '>=', DB::raw('NOW()'))
                                        ->get();
                                @endphp
                                @empty($sentRequests->count())
                                    <div class="text-gray-500 dark:text-gray-400">
                                        {{ __('no_sent_requests') }}
                                    </div>
                                @endempty
                                @foreach ($sentRequests as $request)
                                    <livewire:tutoring-request :validatable="false" :request="$request" />
                                @endforeach
                            </div>
                        </div>
                    @endrole


                    @role(Roles::Tutor->value)
                        <div class="hidden p-4 bg-white rounded-lg md:p-8 dark:bg-gray-800" id="received" role="tabpanel"
                            aria-labelledby="received-tab">
                            <div class="flex flex-wrap -m-2">
                                @php
                                    $receivedRequests = auth()
                                        ->user()
                                        ->receivedRequests()
                                        ->where('end_date', '>=', DB::raw('NOW()'))
                                        ->get();
                                @endphp
                                @if (empty($receivedRequests->count()))
                                    <div class="text-gray-500 dark:text-gray-400">
                                        {{ __('no_received_requests') }}
                                    </div>
                                @else
                                    @foreach ($receivedRequests->filter(fn($request) => $request->status === RequestStatus::Pending) as $request)
                                        <livewire:tutoring-request :validatable="true" :request="$request" />
                                    @endforeach
                                    <hr class="h-px my-8 bg-gray-200 border-0 dark:bg-gray-700 block w-full">
                                    @foreach ($receivedRequests->filter(fn($request) => $request->status !== RequestStatus::Pending) as $request)
                                        <livewire:tutoring-request :validatable="true" :request="$request" />
                                    @endforeach
                                @endif
                            </div>
                        </div>
                    @endrole

                </div>
            </div>
        </div>
    </div>
</x-app-layout>
