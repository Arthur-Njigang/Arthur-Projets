<x-guest-layout>
    <div class="">
        <section class="text-gray-600 body-font">
            <div class="container mx-auto flex px-5 pt-10 pb-24 md:flex-row flex-col items-center">
                <div
                    class="lg:flex-grow md:w-1/2 lg:pr-24 md:pr-16 flex flex-col md:items-start md:text-left mb-16 md:mb-0 items-center text-center">
                    <h1 class="title-font sm:text-4xl text-3xl mb-4 font-medium text-gray-900">
                        Découvrez une nouvelle façon
                        <br class="hidden lg:inline-block">
                        d'apprendre
                    </h1>
                    <p class="mb-8 leading-relaxed">
                        Parcourez notre liste de tuteurs et trouvez celui qui vous convient le mieux, tous les profils
                        sont vérifiés et approuvés par notre équipe.
                        Cours à distance ou en personne, vous avez le choix, et cela à un prix abordable. N’hésitez plus
                        et commencez dès maintenant.
                    </p>
                    <div class="flex justify-center">
                        <a href="{{ route('register') }}?tutor=true"
                            class="inline-flex text-white bg-primary-500 border-0 py-2 px-6 focus:outline-none hover:bg-primary-600 rounded-md text-lg">
                            Devenir Tuteur</a>
                        <a href="{{ route('register') }}"
                            class="ml-4 inline-flex text-white bg-blue-600 border-0 py-2 px-6 focus:outline-none hover:bg-blue-700 rounded-md text-lg">
                            Commencer comme apprenant
                        </a>
                    </div>
                </div>
                <div class="lg:max-w-lg lg:w-full md:w-1/2 w-5/6">
                    <img class="object-cover object-center rounded-lg transform rotate-3" alt="hero"
                        src="https://source.unsplash.com/random/720x600/?teaching">
                </div>
            </div>
        </section>
        <section class="text-gray-600 body-font">
            <div class="container px-5 py-24 mx-auto">
                <div class="flex flex-col text-center w-full mb-20">
                    </h2>
                    <h1 id="tutors-list" class="sm:text-3xl text-2xl font-medium title-font mb-4 text-gray-900">
                        Nos Tuteurs
                    </h1>
                    <p class="lg:w-2/3 mx-auto leading-relaxed text-base">
                        Parcourez et filtrez notre liste de tuteurs et trouvez celui qui vous convient le mieux, tous
                        les profils sont vérifiés et approuvés par notre équipe.
                    </p>
                </div>
                <livewire:profile-search />
            </div>
    </div>
    </section>
    </div>
</x-guest-layout>
