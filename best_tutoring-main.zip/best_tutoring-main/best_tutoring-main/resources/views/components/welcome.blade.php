@php
    use App\Enums\Roles;
@endphp
<div
    class="p-6 lg:p-8 bg-white dark:bg-gray-800 dark:bg-gradient-to-bl dark:from-gray-700/50 dark:via-transparent border-b border-gray-200 dark:border-gray-700">
    <div class="flex items-center">
        <x-application-logo class="block h-12 w-auto mr-4" />

        <h1 class="text-2xl font-medium text-gray-900 dark:text-white">
            {{ __('welcome_message', ['name' => config('app.name')]) }}
        </h1>
    </div>

    <p class="mt-3 text-gray-500 dark:text-gray-400 leading-relaxed">
        {{ __('welcome_message_detail') }}
    <div class="pt-4 space-x-4">
        @role(Roles::Student->value)
            <a href="{{ route('home') }}#tutors-list"
                class="mt-4 text-white bg-primary-500 hover:bg-primary-600 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-3 py-2 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-primary-600 dark:focus:ring-primary-700">
                {{ __('explore') }}
            </a>
        @endrole

        @role(Roles::Tutor->value)
            <a href="{{ route('profiles') }}"
                class="mt-4 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-3 py-2 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                {{ __('become_tutor') }}
            </a>
        @endrole
    </div>
    </p>
</div>
