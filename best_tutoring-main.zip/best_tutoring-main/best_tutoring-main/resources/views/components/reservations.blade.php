<x-dynamic-component :component="$getFieldWrapperView()" :id="$getId()" :label="$getLabel()" :label-sr-only="$isLabelHidden()" :helper-text="$getHelperText()"
    :hint="$getHint()" :hint-action="$getHintAction()" :hint-color="$getHintColor()" :hint-icon="$getHintIcon()" :required="$isRequired()" :state-path="$getStatePath()">
    <div x-data="{ reservations: $wire.entangle('{{ $getStatePath() }}').defer }">
        <div x-show="reservations && reservations.length">
            <template x-for="reservation in reservations">
                <span class="block font-normal text-gray-600"
                    x-text="reservation.start_time + ' - ' + reservation.end_time">
                </span>
            </template>
        </div>
        <div x-show="!(reservations && reservations.length)">
            Aucune réservation
        </div>
    </div>
</x-dynamic-component>
