<div class="w-full h-full">
    <livewire:profile-item :profile="$getRecord()" :wire:key="$getRecord()->id" />
</div>
