<x-app-layout>
    <x-slot name="header">
        <h2
            class="flex items-center justify-between font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('tutor_profiles') }}
            <a href="{{ route('create-profile') }}" type="button"
                class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-3 py-2 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class="w-5 h-5 mr-1 -ml-1">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                </svg>
                Nouveau
            </a>
            {{-- <x-button icon="plus" label="Nouveau" class="" /> --}}
        </h2>
    </x-slot>

    <div class="py-12 space-y-4">
        @foreach (auth()->user()->tutorProfiles as $profile)
            <livewire:profile-detail-item :profile="$profile" :wire:key="$profile->id" />
        @endforeach
    </div>
</x-app-layout>
