import "./bootstrap";

import Alpine from "alpinejs";
import focus from "@alpinejs/focus";
import "flowbite";
import FormsAlpinePlugin from "../../vendor/filament/forms/dist/module.esm";
import NotificationsAlpinePlugin from "../../vendor/filament/notifications/dist/module.esm";
// import Collapse from "@alpinejs/collapse";

// Alpine.plugin(Collapse);
Alpine.plugin(FormsAlpinePlugin);
Alpine.plugin(NotificationsAlpinePlugin);
window.Alpine = Alpine;

Alpine.plugin(focus);

Alpine.start();
