<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::table('users', function (Blueprint $table) {
            // Drop location_id column
            $table->dropForeign('users_location_id_foreign');
            // Add longitude and latitude fields.
            $table->float('lng');
            $table->float('lat');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::table('users', function (Blueprint $table) {
            // restore location_id column
            $table->foreignId('location_id')->nullable()->constrained('locations');
            // Drop longitude and latitude fields.
            $table->dropColumn('lng');
            $table->dropColumn('lat');
        });
    }
};
