<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::create('tutoring_requests', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            // Add status, score, comment, start_date and end_date fields.
            $table->string('status');
            $table->unsignedFloat('score')->nullable();
            $table->text('comment')->nullable();
            $table->dateTime('start_date');
            $table->dateTime('end_date');
            // Add user_id, tutor_profile_id, and time_slot_id foreign keys.
            $table->foreignId('user_id')->constrained('users');
            $table->foreignId('tutor_profile_id')->constrained('tutor_profiles');
            $table->foreignId('time_slot_id')->constrained('time_slots');
            // Add soft delete column.
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('tutoring_requests');
    }
};
