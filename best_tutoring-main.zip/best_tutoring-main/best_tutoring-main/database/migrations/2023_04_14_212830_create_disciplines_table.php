<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::create('disciplines', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            // Add name and description fields.
            $table->string('name');
            $table->text('description')->nullable();
            // Add soft delete column.
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('disciplines');
    }
};
