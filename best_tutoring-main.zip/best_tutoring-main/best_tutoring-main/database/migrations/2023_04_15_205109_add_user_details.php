<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::table('users', function (Blueprint $table) {
            // Add phone, wa_phone and edu_level fields.
            $table->string('phone')->nullable();
            $table->string('wa_phone')->nullable();
            $table->string('edu_level')->nullable();
            // Add soft delete column.
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::table('users', function (Blueprint $table) {
            // Remove phone, wa_phone and edu_level fields.
            $table->dropColumn('phone');
            $table->dropColumn('wa_phone');
            $table->dropColumn('edu_level');
            // Remove soft delete column.
            $table->dropSoftDeletes();
        });
    }
};
