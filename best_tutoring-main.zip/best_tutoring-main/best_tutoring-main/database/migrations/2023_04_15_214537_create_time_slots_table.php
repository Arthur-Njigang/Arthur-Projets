<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::create('time_slots', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            // Add weekday, start_time and end_time fields.
            $table->unsignedInteger('weekday');
            $table->time('start_time');
            $table->time('end_time');
            // Add tutor_profile_id foreign key.
            $table->foreignId('tutor_profile_id')->constrained('tutor_profiles');
            // Add soft delete column.
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('time_slots');
    }
};
