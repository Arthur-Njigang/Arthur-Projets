<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::table('tutoring_requests', function (Blueprint $table) {
            // add remote boolean field
            $table->boolean('remote')->default(false);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::table('tutoring_requests', function (Blueprint $table) {
            // drop remote boolean field
            $table->dropColumn('remote');
        });
    }
};
