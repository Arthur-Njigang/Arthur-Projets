<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::create('experiences', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            // Add title, type, description, start_date and end_date fields.
            $table->string('title');
            $table->string('type');
            $table->text('description')->nullable();
            $table->date('start_date');
            $table->date('end_date')->nullable();
            // Add tutor_profile_id foreign key.
            $table->foreignId('tutor_profile_id')->constrained('tutor_profiles');
            // Add soft delete column.
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('experiences');
    }
};
