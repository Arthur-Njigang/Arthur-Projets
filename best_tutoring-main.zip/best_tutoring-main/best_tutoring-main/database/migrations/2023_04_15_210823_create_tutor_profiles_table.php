<?php

use App\Models\TutorProfile;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
        Schema::create('tutor_profiles', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            // Add status and hourly_rate fields.
            $table->integer('status', unsigned: true)->default(1);
            $table->float('hourly_rate')->nullable();
            // Add discipline_id and user_id foreign key.
            $table->foreignId('discipline_id')->constrained('disciplines');
            $table->foreignId('user_id')->constrained('users');
            // Add soft delete column.
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('tutor_profiles');
    }
};
