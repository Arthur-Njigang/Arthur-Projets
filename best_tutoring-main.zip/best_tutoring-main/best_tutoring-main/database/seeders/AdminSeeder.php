<?php

namespace Database\Seeders;

use App\Enums\Roles;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class AdminSeeder extends Seeder {
    /**
     * Run the database seeds.
     */
    public function run(): void {
        // create default admin user with admin and super-admin roles
        $adminUser = \App\Models\User::factory()->create([
            'name' => 'Admin',
            'email' => 'admin@besttutoring.test',
            'password' => bcrypt('password'),
        ]);
        $adminUser->assignRole([Roles::Admin->value, Roles::SuperAdmin->value]);
    }
}
