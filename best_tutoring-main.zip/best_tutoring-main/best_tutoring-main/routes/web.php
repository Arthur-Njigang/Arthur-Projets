<?php

use App\Enums\Roles;
use App\Models\TutorProfile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('home');

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified'
])->prefix('dashboard')->group(function () {
    Route::get('/', function () {
        return view('dashboard');
    })->name('dashboard');
    Route::prefix('profiles')->middleware(['role:' . Roles::Tutor->value])->group(function () {
        Route::get('/', function () {
            return view('profiles');
        })->name('profiles');
        Route::get('/create', function () {
            return view('profile-add');
        })->name('create-profile');
        Route::get('/{id}/edit', function ($id) {
            return view('profile-edit', ['profile' => TutorProfile::findOrFail($id)]);
        })->name('edit-profile');
    });
    Route::get('/requests', function () {
        return view('requests');
    })->name('requests');
});
