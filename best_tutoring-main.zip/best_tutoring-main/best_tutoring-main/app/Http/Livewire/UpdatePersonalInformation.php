<?php

namespace App\Http\Livewire;

use App\Enums\EduLevel;
use App\Models\User;
use Cheesegrits\FilamentGoogleMaps\Fields\Geocomplete;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Livewire\Component;

class UpdatePersonalInformation extends Component implements HasForms {
    use InteractsWithForms;

    public User $user;

    public function mount() {
        $this->user = auth()->user();
        $this->form->fill($this->user->toArray());
    }

    protected function getFormSchema(): array {
        return [
            TextInput::make('phone')->tel()
                // ->prefix('+32')
                ->label('phone')->translateLabel(),
            TextInput::make('wa_phone')->tel()
                // ->prefix('+32')
                ->label('wa_phone')->translateLabel(),
            Select::make('edu_level')->options(EduLevel::options())
                ->label('edu_level')->translateLabel(),
            Geocomplete::make('location')
                ->isLocation()
                ->geocodeOnLoad()
                ->countries(['be'])
                ->debug() // output the results of reverse geocoding in the browser console, useful for figuring out symbol formats
                ->geolocate()
                ->label('location')->translateLabel(),
        ];
    }

    public function save() {
        // $data = $this->form->getState();
        // $data = array_merge($data, [
        //     'phone' => $data['phone'] ? '+32' . $data['phone'] : null,
        //     'wa_phone' => $data['wa_phone'] ? '+32' . $data['wa_phone'] : null,
        // ]);
        $this->user->update(
            $this->form->getState(),
        );
    }

    protected function getFormModel(): User {
        return $this->user;
    }

    public function render() {
        return view('livewire.update-personal-information');
    }
}
