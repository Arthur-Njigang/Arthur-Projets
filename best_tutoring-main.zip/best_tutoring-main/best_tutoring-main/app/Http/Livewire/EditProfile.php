<?php

namespace App\Http\Livewire;

use App\Models\TutorProfile;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Livewire\Component;

class EditProfile extends Component implements HasForms {
    use InteractsWithForms;

    public TutorProfile $profile;

    public function mount(TutorProfile $profile) {
        $this->profile = $profile;
        // dd($this->profile->toArray());
        $this->form->fill($this->profile->toArray());
    }

    protected function getFormSchema(): array {
        return TutorProfile::getFormSchema(true);
    }

    public function save() {
        $this->profile->fill(
            $this->form->getState(),
        );
        if ($this->profile->isStatus(TutorProfile::$STATUS_REJECTED)) {
            $this->profile->resetStatus();
            $this->profile->reviewStatus();
        }
        $this->profile->save();

        return redirect()->route('profiles');
    }

    protected function getFormModel(): TutorProfile {
        return $this->profile;
    }

    public function render() {
        return view('livewire.edit-profile');
    }
}
