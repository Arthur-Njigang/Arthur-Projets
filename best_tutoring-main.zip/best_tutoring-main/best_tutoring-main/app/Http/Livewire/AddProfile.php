<?php

namespace App\Http\Livewire;

use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Livewire\Component;
use App\Models\TutorProfile;

class AddProfile extends Component implements HasForms {
    use InteractsWithForms;

    public function mount() {
        $this->form->fill([
            'user_id' => auth()->user()->id,
        ]);
    }

    protected function getFormSchema(): array {
        return TutorProfile::getFormSchema(false);
    }

    public function save() {
        $tutorProfile = TutorProfile::create($this->form->getState());

        $this->form->model($tutorProfile)->saveRelationships();

        return redirect()->route('profiles');
    }

    protected function getFormModel(): string {
        return TutorProfile::class;
    }

    public function render() {
        return view('livewire.add-profile');
    }
}
