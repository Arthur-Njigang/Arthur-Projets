<?php

namespace App\Http\Livewire;

use App\Models\TutorProfile;
use Closure;
use Filament\Tables\Columns\Layout\View;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Filters\Layout;
use Illuminate\Contracts\Pagination\Paginator;
use Illuminate\Database\Eloquent\Builder;
use Livewire\Component;

class ProfileSearch extends Component implements HasTable {
    use InteractsWithTable;

    protected $queryString = [
        'tableFilters',
        'tableSortColumn',
        'tableSortDirection',
        'tableSearchQuery' => ['except' => ''],
        'tableColumnSearchQueries',
    ];

    protected function getTableQuery(): Builder {
        return TutorProfile::where('status', '&', TutorProfile::$STATUS_VALID);
    }

    protected function getTableContentGrid(): ?array {
        return [
            'md' => 2,
            '2xl' => 3,
        ];
    }

    protected function getTableColumns(): array {
        return [
            View::make('profile-row')
        ];
    }

    protected function getTableFilters(): array {
        return TutorProfile::getFilters();
    }

    protected function getTableFiltersLayout(): ?string {
        return Layout::AboveContent;
    }

    protected function getTableActions(): array {
        return [];
    }

    protected function getTableBulkActions(): array {
        return [];
    }

    protected function isTablePaginationEnabled(): bool {
        return true;
    }

    protected function getTableRecordsPerPageSelectOptions(): array {
        return [10, 25, 50, 100];
    }

    protected function paginateTableQuery(Builder $query): Paginator {
        return $query->simplePaginate($this->getTableRecordsPerPage() == -1 ? $query->count() : $this->getTableRecordsPerPage());
    }

    protected function getTableRecordActionUsing(): ?Closure {
        // return fn (): string => 'edit';
        return null;
    }

    protected function getTableEmptyStateIcon(): ?string {
        return 'heroicon-o-x';
    }

    protected function getTableEmptyStateHeading(): ?string {
        return 'Pas de profils correspondants';
    }

    protected function getTableEmptyStateDescription(): ?string {
        return 'Essayez de modifier vos filtres de recherche.';
    }

    public function render() {
        return view('livewire.profile-search');
    }
}
