<?php

namespace App\Http\Livewire;

use App\Enums\RequestStatus;
use App\Enums\WeekDay;
use App\Models\TutoringRequest;
use App\Models\TutorProfile;
use App\Notifications\RequestReceived;
use Carbon\Carbon;
use Closure;
use DateTime;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\TimePicker;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\ViewField;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Illuminate\Database\Eloquent\Builder;
use Livewire\Component;

class ProfileItem extends Component implements HasForms {
    use InteractsWithForms;

    public TutorProfile $profile;
    public bool $cardModal = false;
    public bool $detailing = false;
    public static $maxDays = 62;

    public function mount() {
        $this->form->fill();
        setlocale(LC_TIME, 'IT_it');
    }

    public function open() {
        $this->cardModal = true;
    }

    protected function getFormSchema(): array {
        return [
            DatePicker::make('booking_date')
                ->minDate(now())
                ->maxDate(Carbon::now()->addDays(static::$maxDays))
                ->disabledDates(
                    array_values(
                        array_filter(
                            array_map(
                                fn ($days) => Carbon::now()->addDays($days),
                                range(0, static::$maxDays)
                            ),
                            fn (string $date) => !$this->matchesWeekday($date)
                        )
                    )
                )
                ->required()->rules([
                    fn () => (fn (string $attribute, $value, Closure $fail) => $this->matchesWeekday($value) ?
                        true :
                        $fail(__('Date doesn\'t match any time slots'))
                    ),
                ])->label('booking_date')->translateLabel()
                ->reactive()->afterStateUpdated(fn ($state, callable $set) => $set('reservations', $this->reservations($state))),
            ViewField::make('reservations')->view('components.reservations'),
            TimePicker::make('start_time')
                ->withoutSeconds()
                ->required()
                ->label('start_time')->translateLabel(),
            TimePicker::make('end_time')
                ->withoutSeconds()
                ->after('start_time')
                ->required()
                ->label('end_time')->translateLabel(),
            Toggle::make('remote')
                ->onIcon('heroicon-s-desktop-computer')
                ->offIcon('heroicon-s-home')
                ->label('remote_course')->translateLabel()
                ->default(false)->visible((bool)$this->profile->remote),
        ];
    }

    public function reservations(string $date) {
        return $date ?
            array_values(
                $this->profile->tutoringRequests->filter(
                    fn (TutoringRequest $request) => $request->status === RequestStatus::Accepted and
                        $request->start_date->format('Y-m-d') === date_create($date)->format('Y-m-d')
                )->map(
                    fn (TutoringRequest $reservation) => (object)[
                        'start_time' => $reservation->start_date->format('H:i'),
                        'end_time' => $reservation->end_date->format('H:i'),
                    ]
                )->toArray()
            ) : [];
    }

    public function matchesWeekday(string $date): bool {
        return $this->profile->timeSlots->pluck('weekday')->contains(
            $this->weekday($date)
        );
    }

    public function weekday(string $date): WeekDay {
        return WeekDay::from((int)date_create($date)->format('N'));
    }

    public function inRange(DateTime $from, DateTime $to, DateTime $target): bool {
        return $from <= $target && $target <= $to;
    }

    public function timeSlot(array $data) {
        return $this->profile->timeSlots->first(function ($timeSlot) use ($data) {
            if ($timeSlot->weekday == $this->weekday($data['booking_date'])) {
                return $this->inRange(
                    date_create($timeSlot->start_time),
                    date_create($timeSlot->end_time),
                    date_create($data['start_time'])
                ) and $this->inRange(
                    date_create($timeSlot->start_time),
                    date_create($timeSlot->end_time),
                    date_create($data['end_time'])
                );
            }
            return false;
        });
    }

    public function details() {
        $this->profile
            ->load('ratings.user')
            ->loadCount(['ratings as ratings_count'])
            ->loadAvg('ratings as rating', 'score');
        $this->detailing = true;
    }

    public function overlaps(string $start_date, string $end_date): bool {
        return $this->profile->tutoringRequests()->where('status', RequestStatus::Accepted->value)
            ->where(
                fn (Builder $query) => $query
                    ->where(fn (Builder $query) => $query->where('start_date', '<=', $start_date)->where('end_date', '>=', $start_date))
                    ->orWhere(fn (Builder $query) => $query->where('start_date', '<=', $end_date)->where('end_date', '>=', $end_date))
                    ->orWhere(fn (Builder $query) => $query->where('start_date', '>=', $start_date)->where('end_date', '<=', $end_date))
            )
            ->exists();
    }

    public function book() {
        $data = $this->form->getState();
        // dd($data);
        $timeSlot = $this->timeSlot($data);
        if ($timeSlot) {
            $start_date = "{$data['booking_date']} {$data['start_time']}";
            $end_date = "{$data['booking_date']} {$data['end_time']}";
            if (!$this->overlaps($start_date, $end_date)) {
                $request = TutoringRequest::create([
                    'user_id' => auth()->user()->id,
                    'time_slot_id' => $timeSlot->id,
                    'tutor_profile_id' => $this->profile->id,
                    'start_date' => date_create($start_date),
                    'end_date' => date_create($end_date),
                    'status' => RequestStatus::Pending,
                    'remote' => $data['remote'] ?? false,
                ]);
                $this->profile->user->notify(new RequestReceived($request));

                return redirect()->route('requests');
            }
        }
        session()->flash('error', __('invalid_time_slot'));
    }

    protected function getFormModel(): string {
        return TutoringRequest::class;
    }


    public function render() {
        return view('livewire.profile-item');
    }
}
