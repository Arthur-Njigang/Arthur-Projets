<?php

namespace App\Http\Livewire;

use App\Models\TutorProfile;
use Livewire\Component;

class ProfileDetailItem extends Component {

    public TutorProfile $profile;

    public function deleteProfile() {
        $this->profile->delete();
        return redirect()->route('profiles');
    }

    public function render() {
        return view('livewire.profile-detail-item');
    }
}
