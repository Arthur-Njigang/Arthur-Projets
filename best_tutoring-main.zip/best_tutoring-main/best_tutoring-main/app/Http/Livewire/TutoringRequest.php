<?php

namespace App\Http\Livewire;

use App\Enums\RequestStatus;
use App\Models\TutoringRequest as ModelsTutoringRequest;
use App\Notifications\RequestResponded;
use Filament\Forms\Components\Grid;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Yepsua\Filament\Forms\Components\Rating;
use Livewire\Component;

class TutoringRequest extends Component implements HasForms {
    use InteractsWithForms;

    public $validatable = false;
    public ModelsTutoringRequest $request;

    public function mount() {
        $this->form->fill(
            $this->request->toArray(),
        );
    }

    public function accept() {
        $this->update(RequestStatus::Accepted);
    }

    public function reject() {
        $this->update(RequestStatus::Rejected);
    }

    public function update(RequestStatus $status) {
        $this->request->status = $status;
        $this->request->save();
        $this->notify();
    }

    // Notify user that the request has been responded to
    public function notify() {
        $this->request->user->notify(new RequestResponded($this->request));
    }

    protected function getFormSchema(): array {
        return [
            Grid::make([
                'default' => 2,
            ])->schema([
                Rating::make('score')
                    ->required()
                    ->disabled((bool)$this->request->score)
                    ->label('score')->translateLabel(),
                Textarea::make('comment')
                    ->disabled((bool)$this->request->score)
                    ->label('comment')->translateLabel()
                    ->rows(1)->columnSpan(2),
            ])
        ];
    }

    public function saveRating() {
        $this->request->update(
            $this->form->getState(),
        );
    }

    public function render() {
        return view('livewire.tutoring-request');
    }
}
