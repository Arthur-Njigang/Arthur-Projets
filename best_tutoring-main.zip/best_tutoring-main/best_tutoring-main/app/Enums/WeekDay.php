<?php

namespace App\Enums;

use App\Traits\EnumToArray;

enum WeekDay: int {
    use EnumToArray;

    case Lundi = 1;
    case Mardi = 2;
    case Mercredi = 3;
    case Jeudi = 4;
    case Vendredi = 5;
    case Samedi = 6;
    case Dimanche = 7;
}
