<?php

namespace App\Enums;

use App\Traits\EnumToArray;

enum EduLevel: string {
    use EnumToArray;

    case Aucun = 'Aucun';
    case Primaire = 'Primaire';
    case Secondaire = 'Secondaire';
    case CESS = 'CESS';
    case Bachelier = 'Bachelier';
    case Master = 'Master';
    case Doctorat = 'Doctorat';
}
