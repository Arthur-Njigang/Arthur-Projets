<?php

namespace App\Enums;

use App\Traits\EnumToArray;

enum ExperienceType: string {
    use EnumToArray;

    case INTERNSHIP = 'Stage';
    case EMPLOYMENT = 'Emploi';
    case VOLUNTEERING = 'Bénévolat';
    case OTHER = 'Autre';
}
