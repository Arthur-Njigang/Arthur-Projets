<?php

namespace App\Enums;

use App\Traits\EnumToArray;

enum Roles: string {
    use EnumToArray;

    case Admin = 'admin';
    case SuperAdmin = 'super-admin';
    case Student = 'student';
    case Tutor = 'tutor';

    // extra helper to allow for greater customization of displayed values, without disclosing the name/value data directly
    public function label(): string {
        return match ($this) {
            static::Admin => 'Admin',
            static::SuperAdmin => 'Super Admin',
            static::Student => 'Student',
            static::Tutor => 'Tutor',
        };
    }
}
