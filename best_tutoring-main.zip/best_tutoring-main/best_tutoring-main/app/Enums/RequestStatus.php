<?php

namespace App\Enums;

use App\Traits\EnumToArray;

enum RequestStatus: string {
    use EnumToArray;

    case Pending = 'En attente';
    case Accepted = 'Acceptée';
    case Rejected = 'Rejetée';

    public function color(): string {
        return match ($this) {
            static::Pending => 'gray',
            static::Accepted => 'green',
            static::Rejected => 'red',
        };
    }
}
