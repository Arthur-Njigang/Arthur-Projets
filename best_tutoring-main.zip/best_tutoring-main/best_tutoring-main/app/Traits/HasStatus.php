<?php

namespace App\Traits;

trait HasStatus {

    public static $STATUS_CREATED = 1;
    public static $STATUS_IN_REVIEW = 2;
    public static $STATUS_VALID = 4;
    public static $STATUS_WAS_VALID = 8;
    public static $STATUS_REJECTED = 16;

    // Check if the tutor profile is a given status
    public static function hasStatus($ref, $status): bool {
        return (bool) ($ref & $status);
    }

    // Check if the tutor profile is a given status
    public function isStatus($status): bool {
        return static::hasStatus($this->status, $status);
    }

    // Set the status of the tutor profile
    public function setStatus($status) {
        if (!$this->isStatus($status)) $this->status += $status;
    }

    // Unset status of the tutor profile
    public function unsetStatus($status) {
        if ($this->isStatus($status)) $this->status -= $status;
    }

    // Check if the tutor profile is valid
    public function isValid($strict = true): bool {
        return $this->isStatus(static::$STATUS_VALID) or ($strict ? false : $this->isStatus(static::$STATUS_WAS_VALID));
    }

    // Reset the status of the tutor profile
    public function resetStatus() {
        $this->unsetStatus(static::$STATUS_IN_REVIEW);
        $this->unsetStatus(static::$STATUS_VALID);
        $this->unsetStatus(static::$STATUS_REJECTED);
    }

    // Validate the status of the tutor profile
    public function validateStatus() {
        $this->resetStatus();
        $this->setStatus(static::$STATUS_VALID);
        $this->unsetStatus(static::$STATUS_WAS_VALID);
    }

    // Reject the status of the tutor profile
    public function rejectStatus() {
        // if status is valid, set status to was valid
        if ($this->isStatus(static::$STATUS_VALID)) $this->setStatus(static::$STATUS_WAS_VALID);
        $this->resetStatus();
        $this->setStatus(static::$STATUS_REJECTED);
    }

    // Review the status of the tutor profile
    public function reviewStatus() {
        $this->setStatus(static::$STATUS_IN_REVIEW);
    }

    public function activate() {
        $this->validateStatus();
        $this->save();
    }

    public function deactivate() {
        $this->rejectStatus();
        $this->save();
    }

    public function getStatusTextAttribute() {
        return $this->statusText($this->status);
    }

    public function getStatusColorAttribute() {
        return $this->statusColor($this->status);
    }

    public static function statusText($status) {
        if (static::hasStatus($status, static::$STATUS_REJECTED)) return __('status.rejected');
        if (static::hasStatus($status, static::$STATUS_WAS_VALID)) return __('status.valid');
        if (static::hasStatus($status, static::$STATUS_VALID)) return __('status.valid');
        if (static::hasStatus($status, static::$STATUS_IN_REVIEW)) return __('status.in_review');
        if (static::hasStatus($status, static::$STATUS_CREATED)) return __('status.created');
        return __('unknown');
    }

    public static function statusColor($status) {
        if (static::hasStatus($status, static::$STATUS_REJECTED)) return 'bg-danger-500/10 text-danger-700 dark:bg-danger-900 dark:text-danger-300';
        if (static::hasStatus($status, static::$STATUS_WAS_VALID)) return 'bg-success-500/10 text-success-700 dark:bg-success-900 dark:text-success-300';
        if (static::hasStatus($status, static::$STATUS_VALID)) return 'bg-success-500/10 text-success-700 dark:bg-success-900 dark:text-success-300';
        if (static::hasStatus($status, static::$STATUS_IN_REVIEW)) return 'bg-primary-500/10 text-primary-700 dark:bg-primary-900 dark:text-primary-300';
        if (static::hasStatus($status, static::$STATUS_CREATED)) return 'bg-secondary-500/10 text-secondary-700 dark:bg-secondary-900 dark:text-secondary-300';
        return '';
    }
}
