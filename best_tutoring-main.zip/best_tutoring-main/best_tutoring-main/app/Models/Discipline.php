<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Discipline extends Model {
    use HasFactory;
    use SoftDeletes;

    protected $table = 'disciplines';
    protected $fillable = [
        'name',
        'description',
    ];

    // Declare relationship with TutorProfile (has many)
    public function tutorProfiles() {
        return $this->hasMany(TutorProfile::class);
    }
}
