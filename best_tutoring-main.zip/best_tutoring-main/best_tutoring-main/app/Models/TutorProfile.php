<?php

namespace App\Models;

use App\Traits\HasStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use App\Enums\ExperienceType;
use App\Enums\WeekDay;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Grid;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\SpatieMediaLibraryFileUpload;
use Filament\Forms\Components\TimePicker;
use Illuminate\Validation\Rules\Unique;
use Spatie\MediaLibrary\MediaCollections\File;
use App\Enums\EduLevel;
use App\Enums\RequestStatus;
use Filament\Tables\Filters\SelectFilter;
use Illuminate\Support\Facades\DB;
use Cheesegrits\FilamentGoogleMaps\Filters\RadiusFilter;
use Filament\Forms\Components\Toggle;

class TutorProfile extends Model implements HasMedia {
    use HasFactory;
    // use SoftDeletes;
    use InteractsWithMedia;
    use HasStatus;

    /**
     * The database table associated with the model.
     *
     * @var string
     */
    protected $table = 'tutor_profiles';

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'discipline_id',
        'user_id',
        'hourly_rate',
        'remote',
    ];

    /**
     * The relationships that should always be loaded.
     *
     * @var array
     */
    protected $with = ['discipline', 'user', 'experiences', 'timeSlots'];

    public function registerMediaCollections(): void {
        $this->addMediaCollection('avatar')
            // Accept only images
            ->acceptsFile(function (File $file) {
                return  preg_match("/^image\/(jpeg|jpg|png|gif|bmp|svg|webp)$/i", $file->mimeType);
            })
            ->singleFile();

        $this->addMediaCollection('cv')->singleFile();
    }

    // get the avatar url or related usera avatar url
    public function getAvatarUrlAttribute() {
        return $this->getFirstMediaUrl('avatar') ?: $this->user->profile_photo_url;
    }

    // Declare the inverse relationship
    public function user() {
        return $this->belongsTo(User::class);
    }

    // Declare relationship with discipline
    public function discipline() {
        return $this->belongsTo(Discipline::class);
    }

    // Declare relationship with Experience (has many)
    public function experiences() {
        return $this->hasMany(Experience::class);
    }

    // Declare relationship with TutoringRequest (has many)
    public function tutoringRequests() {
        return $this->hasMany(TutoringRequest::class);
    }

    public function requests() {
        return $this->tutoringRequests()->where('end_date', '>=', DB::raw('NOW()'));
    }

    public function acceptedRequests() {
        return $this->requests()->where('status', RequestStatus::Accepted->value);
    }

    public function ratings() {
        return $this->tutoringRequests()->whereNotNull('score')->orderBy('updated_at', 'desc');
    }

    // Declare relationship with TimeSlot (has many)
    public function timeSlots() {
        return $this->hasMany(TimeSlot::class);
    }

    public static function getFilters(): array {
        return [
            SelectFilter::make('edu_level')
                ->attribute('user.edu_level')
                ->multiple()
                ->options(EduLevel::options())
                ->label('edu_level')->translateLabel(),
            SelectFilter::make('discipline')
                ->multiple()
                ->relationship('discipline', 'name')
                ->label('discipline')->translateLabel(),
            RadiusFilter::make('radius')
                ->attribute('user.location')
                ->selectUnit() // add a Kilometer / Miles select
                ->kilometers()
                ->default(auth()->user()?->location) // use (or default the select to) kilometers (defaults to miles)
                ->section(__('radius_search')) // optionally wrap the filter in a section with heading
                ->label('radius')->translateLabel(),
        ];
    }

    public static function getFormSchema(bool $editing = false): array {
        return [
            Grid::make([
                'default' => 2,
                // 'sm' => 3,
                // 'xl' => 6,
                // '2xl' => 8,
            ])->schema([
                SpatieMediaLibraryFileUpload::make('profile_photo')->collection('avatar')->enableDownload()
                    ->label('profile_photo')->translateLabel(),
                SpatieMediaLibraryFileUpload::make('cv')->collection('cv')->enableDownload()
                    ->required()
                    ->label('cv')->translateLabel(),
                Toggle::make('remote')
                    ->onIcon('heroicon-s-desktop-computer')
                    ->offIcon('heroicon-s-home')
                    ->label('accept_remote')->translateLabel()->columnSpan(2),
                Hidden::make('user_id')->required(),
                Select::make('discipline_id')->relationship('discipline', 'name')
                    ->unique(ignoreRecord: $editing, callback: function (Unique $rule) {
                        return $rule->where('user_id', auth()->user()->id);
                    })
                    ->required()
                    ->disabled($editing),
                TextInput::make('hourly_rate')
                    ->required()->numeric()
                    ->mask(fn (Forms\Components\TextInput\Mask $mask) => $mask->money(prefix: '€', thousandsSeparator: ',', decimalPlaces: 2))
                    ->label('hourly_rate')->translateLabel(),
                Repeater::make('timeSlots')->label('time_slots')->translateLabel()
                    ->relationship()
                    ->schema([
                        Grid::make([
                            'default' => 3,
                            // 'sm' => 3,
                            // 'xl' => 6,
                            // '2xl' => 8,
                        ])->schema([
                            Select::make('weekday')->options(WeekDay::options())->required()->label('weekday')->translateLabel(),
                            TimePicker::make('start_time')->withoutSeconds()->required()->label('start_time')->translateLabel(),
                            TimePicker::make('end_time')->withoutSeconds()->required()->afterOrEqual('end_time')->label('end_time')->translateLabel(),
                        ])
                    ]),
                Repeater::make('experiences')->label('experiences')->translateLabel()
                    ->relationship()
                    ->schema([
                        Grid::make([
                            'default' => 2,
                        ])->schema([
                            TextInput::make('title')->required()
                                ->helperText('Nom de l\'entreprise, titre abrégé de l\'expérience, etc.')
                                ->label('title')->translateLabel()
                                ->columnSpan(2),
                            DatePicker::make('start_date')->required()->label('start_date')->translateLabel(),
                            DatePicker::make('end_date')->nullable()->afterOrEqual('start_date')->label('end_date')->translateLabel(),
                            Select::make('type')->options(ExperienceType::array())->required(),
                            MarkdownEditor::make('description')
                                ->disableToolbarButtons([
                                    'attachFiles',
                                    'codeBlock',
                                ])->label('description')->translateLabel()
                                ->columnSpan(2),
                            SpatieMediaLibraryFileUpload::make('attachments')->collection('media')
                                ->multiple()->enableDownload()
                                ->label('attachments')->translateLabel()
                                ->columnSpan(2)
                        ])
                    ]),
            ])
        ];
    }
}
