<?php

namespace App\Models;

use App\Enums\ExperienceType;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Experience extends Model implements HasMedia {
    use HasFactory;
    use SoftDeletes;
    use InteractsWithMedia;

    protected $table = 'experiences';
    protected $fillable = ['tutor_profile_id', 'type', 'title', 'description', 'start_date', 'end_date'];
    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'start_date' => 'date:Y-m-d',
        'end_date' => 'date:Y-m-d',
        'type' => ExperienceType::class,
    ];

    /**
     * The relationships that should always be loaded.
     *
     * @var array
     */
    protected $with = ['attachments',];

    public function registerMediaCollections(): void {
        $this->addMediaCollection('media');
    }

    public function attachments() {
        return $this->media()->where('collection_name', 'media');
    }

    // Declare inverse relationship with TutorProfile
    public function tutorProfile() {
        return $this->belongsTo(TutorProfile::class);
    }
}
