<?php

namespace App\Models;

use App\Enums\WeekDay;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TimeSlot extends Model {
    use HasFactory;
    use SoftDeletes;

    /**
     * The database table associated with the model.
     *
     * @var string
     */
    protected $table = 'time_slots';
    protected $fillable = ['tutor_profile_id', 'weekday', 'start_time', 'end_time'];
    protected $casts = [
        'start_time' => 'datetime:H:i:s',
        'end_time' => 'datetime:H:i:s',
        'weekday' => WeekDay::class,
    ];

    // Declare inverse relationship with TutorProfile
    public function tutorProfile() {
        return $this->belongsTo(TutorProfile::class);
    }

    // Declare relationship with TutoringRequest (has many)
    public function tutoringRequests() {
        return $this->hasMany(TutoringRequest::class);
    }
}
