<?php

namespace App\Models;

use App\Enums\RequestStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TutoringRequest extends Model {
    use HasFactory;
    use SoftDeletes;

    protected $table = 'tutoring_requests';

    protected $fillable = [
        'tutor_profile_id',
        'user_id',
        'time_slot_id',
        'start_date',
        'end_date',
        'status',
        'score',
        'comment',
        'remote',
    ];

    protected $attributes = [
        'status' => RequestStatus::Pending,
    ];

    /**
     * The relationships that should always be loaded.
     *
     * @var array
     */
    protected $with = ['tutorProfile', 'user', 'timeSlot'];

    protected $casts = [
        'start_date' => 'date:Y-m-d H:i:s',
        'end_date' => 'date:Y-m-d H:i:s',
        'status' => RequestStatus::class,
    ];

    // Declare inverse relationship with TutorProfile
    public function tutorProfile() {
        return $this->belongsTo(TutorProfile::class);
    }

    // Declare inverse relationship with User
    public function user() {
        return $this->belongsTo(User::class);
    }

    // Declare inverse relationship with TimeSlot
    public function timeSlot() {
        return $this->belongsTo(TimeSlot::class);
    }
}
