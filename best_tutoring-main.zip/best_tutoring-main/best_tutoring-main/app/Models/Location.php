<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Location extends Model {
    use HasFactory;
    use SoftDeletes;

    protected $table = 'locations';

    // Declare the inverse relationship
    public function users() {
        return $this->hasOne(User::class);
    }
}
