<?php

namespace App\Filament\Resources;

use App\Filament\Resources\TutorProfileResource\Pages;
use App\Filament\Resources\TutorProfileResource\RelationManagers;
use App\Models\TutorProfile;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\Select;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\BulkAction;
use Filament\Tables\Filters\Layout;
use Illuminate\Database\Eloquent\Collection;

class TutorProfileResource extends Resource {
    protected static ?string $model = TutorProfile::class;

    protected static ?string $navigationIcon = 'heroicon-o-academic-cap';

    public static function form(Form $form): Form {
        return $form
            ->schema(TutorProfile::getFormSchema());
    }

    public static function table(Table $table): Table {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('discipline.name'),
                Tables\Columns\TextColumn::make('user.name')->label('user')->translateLabel(),
                Tables\Columns\BadgeColumn::make('status')->formatStateUsing(fn (int $state): string => TutorProfile::statusText((int)$state))->color(static fn ($state): string => TutorProfile::statusColor((int)$state))->label('status')->translateLabel(),
                Tables\Columns\TextColumn::make('hourly_rate')->money('eur', true)->label('hourly_rate')->translateLabel(),
                Tables\Columns\TextColumn::make('created_at')->label('created_at')->translateLabel()
                    ->since(),
                // Tables\Columns\TextColumn::make('updated_at')->label('updated_at')->translateLabel()
                //     ->since(),
                // Tables\Columns\TextColumn::make('deleted_at')
                //     ->dateTime(),
            ])
            ->filters(TutorProfile::getFilters())
            ->actions([
                Tables\Actions\ViewAction::make(),
                // Tables\Actions\EditAction::make(),
                Action::make('validate')
                    ->label(__('validate'))
                    ->color('success')
                    ->action(fn (TutorProfile $record) => $record->activate()), //@todo conditionally hide this action if the record is already valide
                Action::make('reject')
                    ->label(__('reject'))
                    ->color('danger')
                    ->action(fn (TutorProfile $record) => $record->deactivate()), //@todo conditionally hide this action if the record is already rejected
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
                // BulkAction::make('validate')
                //     ->label(__('validate'))
                //     ->action(fn (Collection $tutorProfiles) => $tutorProfiles->each(fn (TutorProfile $tutorProfile) => $tutorProfile->activate())),
                // BulkAction::make('reject')
                //     ->label(__('reject'))
                //     ->action(fn (Collection $tutorProfiles) => $tutorProfiles->each(fn (TutorProfile $tutorProfile) => $tutorProfile->deactivate())),
            ]);
    }

    protected function getTableFiltersLayout(): ?string {
        return Layout::AboveContent;
    }

    public static function getModelLabel(): string {
        return __('tutor_profile');
    }

    public static function getPluralModelLabel(): string {
        return __('tutor_profiles');
    }

    public static function getRelations(): array {
        return [
            //
        ];
    }

    public static function getPages(): array {
        return [
            'index' => Pages\ListTutorProfiles::route('/'),
            // 'create' => Pages\CreateTutorProfile::route('/create'),
            'view' => Pages\ViewTutorProfile::route('/{record}'),
            // 'edit' => Pages\EditTutorProfile::route('/{record}/edit'),
        ];
    }

    protected function getRedirectUrl(): string {
        return $this->getResource()::getUrl('index');
    }
}
