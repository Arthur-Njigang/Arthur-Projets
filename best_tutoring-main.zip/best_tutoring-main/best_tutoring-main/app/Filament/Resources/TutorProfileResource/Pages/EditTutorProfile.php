<?php

namespace App\Filament\Resources\TutorProfileResource\Pages;

use App\Filament\Resources\TutorProfileResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\EditRecord;

class EditTutorProfile extends EditRecord {
    protected static string $resource = TutorProfileResource::class;

    protected function getActions(): array {
        return [
            Actions\DeleteAction::make(),
        ];
    }

    protected function getRedirectUrl(): string {
        return $this->previousUrl ?? $this->getResource()::getUrl('index');
    }
}
