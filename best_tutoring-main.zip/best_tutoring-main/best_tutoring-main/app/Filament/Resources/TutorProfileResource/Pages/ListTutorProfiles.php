<?php

namespace App\Filament\Resources\TutorProfileResource\Pages;

use App\Filament\Resources\TutorProfileResource;
use App\Models\TutorProfile;
use Filament\Pages\Actions;
use Filament\Pages\Actions\Action;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Collection;

class ListTutorProfiles extends ListRecords {
    protected static string $resource = TutorProfileResource::class;

    protected function getActions(): array {
        return [
            // Actions\CreateAction::make(),
        ];
    }
}
