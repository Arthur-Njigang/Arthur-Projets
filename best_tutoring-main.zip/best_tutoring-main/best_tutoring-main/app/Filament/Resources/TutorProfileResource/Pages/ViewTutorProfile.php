<?php

namespace App\Filament\Resources\TutorProfileResource\Pages;

use App\Filament\Resources\TutorProfileResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewTutorProfile extends ViewRecord
{
    protected static string $resource = TutorProfileResource::class;
}
