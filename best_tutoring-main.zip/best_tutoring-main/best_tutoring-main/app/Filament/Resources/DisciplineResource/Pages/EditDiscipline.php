<?php

namespace App\Filament\Resources\DisciplineResource\Pages;

use App\Filament\Resources\DisciplineResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\EditRecord;

class EditDiscipline extends EditRecord {
    protected static string $resource = DisciplineResource::class;

    protected function getActions(): array {
        return [
            Actions\DeleteAction::make(),
        ];
    }

    protected function getRedirectUrl(): string {
        return $this->previousUrl ?? $this->getResource()::getUrl('index');
    }
}
