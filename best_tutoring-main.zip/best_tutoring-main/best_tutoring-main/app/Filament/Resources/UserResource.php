<?php

namespace App\Filament\Resources;

use App\Enums\EduLevel;
use App\Enums\Roles;
use App\Filament\Resources\UserResource\Pages;
use App\Models\User;
use Filament\Forms;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Filament\Tables\Actions\Action;

class UserResource extends Resource {
    protected static ?string $model = User::class;

    protected static ?string $navigationIcon = 'heroicon-o-user-group';

    public static function form(Form $form): Form {
        return $form
            ->schema([
                Forms\Components\TextInput::make('name')
                    ->required()
                    ->maxLength(255)
                    ->label('name')->translateLabel(),
                Forms\Components\TextInput::make('email')
                    ->email()
                    ->required()
                    ->maxLength(255)
                    ->label('email')->translateLabel(),
                Forms\Components\DateTimePicker::make('email_verified_at')
                    ->label('email_verified_at')->translateLabel(),
                Forms\Components\TextInput::make('password')
                    ->password()
                    ->required()
                    ->maxLength(255)
                    ->visibleOn('create'),
                Forms\Components\TextInput::make('phone')
                    ->tel()
                    ->maxLength(255)
                    ->label('phone')->translateLabel(),
                Forms\Components\TextInput::make('wa_phone')
                    ->tel()
                    ->maxLength(255)
                    ->label('wa_phone')->translateLabel(),
                Forms\Components\Select::make('edu_level')
                    ->options(EduLevel::options())
                    ->label('edu_level')->translateLabel(),
            ]);
    }

    public static function table(Table $table): Table {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('profile_photo_url')->circular()
                    ->label('photo')->translateLabel(),
                Tables\Columns\TextColumn::make('name')
                    ->label('name')->translateLabel(),
                Tables\Columns\TextColumn::make('email')
                    ->label('email')->translateLabel(),
                // Tables\Columns\TextColumn::make('email_verified_at')
                //     ->dateTime('Y-m-d H:i:s')
                //     ->label('email_verified_at')->translateLabel(),
                // Tables\Columns\TextColumn::make('phone')
                //     ->label('phone')->translateLabel(),
                // Tables\Columns\TextColumn::make('wa_phone')
                //     ->label('wa_phone')->translateLabel(),
                // Tables\Columns\TextColumn::make('edu_level')
                //     ->label('edu_level')->translateLabel(),
                Tables\Columns\TextColumn::make('created_at')
                    ->since()
                    ->label('created_at')->translateLabel(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Action::make('make_admin')
                    ->label('make_admin')->translateLabel()
                    ->icon('heroicon-s-user-add')
                    ->visible(fn (User $record): bool => auth()->user()->hasRole(Roles::SuperAdmin->value) && !$record->hasRole(Roles::Admin->value))
                    ->action(fn (User $record) => $record->assignRole(Roles::Admin->value)),
                Action::make('revoke_admin')
                    ->label('revoke_admin')->translateLabel()
                    ->icon('heroicon-s-user-remove')
                    ->visible(fn (User $record): bool => auth()->user()->hasRole(Roles::SuperAdmin->value) && $record->hasRole(Roles::Admin->value))
                    ->hidden(fn (User $record): bool => $record->hasRole(Roles::SuperAdmin->value))
                    ->action(fn (User $record) => $record->removeRole(Roles::Admin->value)),
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),

            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }

    public static function getModelLabel(): string {
        return __('user');
    }

    public static function getPluralModelLabel(): string {
        return __('users');
    }

    public static function getRelations(): array {
        return [
            //
        ];
    }

    public static function getPages(): array {
        return [
            'index' => Pages\ListUsers::route('/'),
            'create' => Pages\CreateUser::route('/create'),
            'view' => Pages\ViewUser::route('/{record}'),
            'edit' => Pages\EditUser::route('/{record}/edit'),
        ];
    }
}
