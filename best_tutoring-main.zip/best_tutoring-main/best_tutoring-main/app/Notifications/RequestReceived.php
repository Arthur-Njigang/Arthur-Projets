<?php

namespace App\Notifications;

use App\Models\TutoringRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class RequestReceived extends Notification implements ShouldQueue {
    use Queueable;

    public TutoringRequest $request;

    /**
     * Create a new notification instance.
     */
    public function __construct(TutoringRequest $request) {
        $this->request = $request;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage {
        return (new MailMessage)
            ->subject(__('New tutoring request'))
            ->line(__('New tutoring request from ') . $this->request->user->name)
            ->action(__('check request'), url()->route('requests'))
            ->line(__('Thank you for using our application!'));
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array {
        return [
            //
        ];
    }
}
