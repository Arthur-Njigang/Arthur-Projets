package controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.internal.junit.ArrayAsserts;

import dao.DAOFactory;
import dao.DAOFactory.TypePersistance;
import databases.connexion.ConnexionFromFile;
import databases.connexion.ConnexionSingleton;
import databases.connexion.IConnexionInfos;
import databases.uri.Databases;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.stage.WindowEvent;
import model.Composant;
import service.Facade;
import service.ListMessages.Classe;
import service.ListMessages.Evenement;
import view.composant.VueComposantController;
import view.composant.VueListeComposantsController;
import view.composant.VueProprieteController;

public class MainController extends Application {
// Logger
	private static final Logger logger = LoggerFactory.getLogger(MainController.class);
//Facade
	private Facade facade;
//Factory
	private DAOFactory factory;

//MainStage
	private Stage mainStage;
	
	List<String> composantPrint = new ArrayList<String>();
	List<String> InformationPrint = new ArrayList<String>();
	
	TextArea InformationArea = new TextArea();
	TextArea ComposantArea = new TextArea();
	
//Lancement de l'application
	@Override
	public void start(Stage mainStage) {
		// mÃ©morise la fÃ©nÃªtre principale
		this.mainStage = mainStage;
		// Connexion Ã  la BD
		try {
			IConnexionInfos info = new ConnexionFromFile("ressources/connexionComposant_Test.properties",
					Databases.FIREBIRD);
			ConnexionSingleton.setInfoConnexion(info);
			Connection connect = ConnexionSingleton.getConnexion();
			logger.info("Connexion Ã©tablie");
			// CrÃ©e la factory Firebird
			factory = DAOFactory.getDAOFactory(TypePersistance.FIREBIRD, connect);
		} catch (Exception e) {
			showErreur("ProblÃ¨me de connexion");
			//Quitte l'application
			Platform.exit();
		}
		// facade
		facade = new Facade(factory);

		BorderPane cp = new BorderPane();
		// Liste de boutons
		VBox leftPane = new VBox();
		Button bt1 = new Button("Affiche Composant");
		leftPane.getChildren().add(bt1);
		//bt1 Affiche composant
		bt1.setOnAction(ev -> {
			ChoiceDialog<String> dlg = new ChoiceDialog<>("---", facade.getListeRefComposant());
			dlg.setHeaderText("Choisir un composant");
			Optional<String> result = dlg.showAndWait();
			result.ifPresent(e -> facade.getComposant(e).ifPresent((c) -> showVueComposant(facade, c)));
		});
		
		//bt2 crÃ©e un nouveau composant
		Button bt2 = new Button("Nouveau Composant");
		bt2.setOnAction(ev -> {
			showVueComposant(facade, null);
		});

		leftPane.getChildren().add(bt2);
		//Affiche la liste des composants
		Button bt3 = new Button("Liste Composants");
		bt3.setOnAction(ev -> {
			showVueListeComposant(facade);
		});

		leftPane.getChildren().add(bt3);
		
		//Affiche la liste des composants
		Button bt4 = new Button("Affiche Proprietes");
		bt4.setOnAction(ev -> {
			ChoiceDialog<String> dlg = new ChoiceDialog<>("---", facade.getListeRefComposant());
			dlg.setHeaderText("Choisir un composant");
			Optional<String> result = dlg.showAndWait();
			result.ifPresent(e -> facade.getComposant(e).ifPresent((c) -> showVuePropriete(facade, c)));
		});

		leftPane.getChildren().add(bt4);
		// panneau de droite
		VBox rightPane = new VBox();
		rightPane.setSpacing(20);
		rightPane.setPadding(new Insets(10));
		
		// panneau des composant
		VBox panel1 = new VBox();
		panel1.setSpacing(10);
		Label TitleComopsant = new Label("Composant");
		ComposantArea.setEditable(false);
		panel1.getChildren().addAll(TitleComopsant, ComposantArea);
		
		// panneau des informations
		VBox panel2 = new VBox();
		panel2.setSpacing(10);
		Label TitleInformation = new Label("Information");
		InformationArea.setEditable(false);
		panel2.getChildren().addAll(TitleInformation, InformationArea);
		
		facade.InformationArea = InformationArea;
		facade.ComposantArea = ComposantArea;	
		
		Button effacer = new Button("Efface Ã©vÃ©nements");
		effacer.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				// TODO Auto-generated method stub
				InformationArea.clear();
				ComposantArea.clear();
			}
		});

		rightPane.getChildren().addAll(panel1, panel2, effacer);
		cp.setRight(rightPane);
		cp.setLeft(leftPane);

		Scene scene = new Scene(cp, 700, 500);
		
		mainStage.setScene(scene);
		mainStage.setTitle("Projet PDB 2122");
		mainStage.show();
	}

	private void showVuePropriete(Facade facade2, Composant composant) {
		// bundle
		ResourceBundle bundle;
		// CrÃ©e une stage
		Stage stage = new Stage();
		// indique sa stage parent
		stage.initOwner(mainStage);
		stage.setX(150);
		stage.setY(200);

		// CrÃ©e un loader pour charger la vue FXML
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/composant/VueProprietes.fxml"));
		try {
			bundle = ResourceBundle.getBundle("view.composant.bundle.VueProprietes");
			loader.setResources(bundle);
			// Obtenir la traduction du titre dans la locale
			stage.setTitle(bundle.getString("propriete.titre"));
		} catch (Exception e) {
			logger.error("Imposible de charger le buddle pour la vue Composant" + e.getMessage());
			showErreur("Impossible de charger le buddle ");
			stage.setTitle("Vue Composant");
		}
		
		// Charge la vue Ã  partir du Loader
		// et initialise son contenu en appelant la mÃ©thode setUp du controleur
		BorderPane root;
		try {
			root = loader.load();
			// rÃ©cupÃ¨re le ctrl (aprÃ¨s l'initialisation)
			VueProprieteController ctrl = loader.getController();
			// fourni la fabrique au ctrl pour charger les articles
			ctrl.setUp(facade, composant, stage);
			// charge le Pane dans la Stage
			Scene scene = new Scene(root, 800, 530);
			scene.getStylesheets().add("./view/css/composant.css");
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			logger.error("Imposible de charger la vue Composant");
			showErreur("Impossible de charger la vue Composant: " + e.getMessage());
			stage = null;
		}
	}



	/**
	 * Permet de modifier ou crÃ©er un nouveau composant
	 * 
	 * @param facade
	 * @param composant le composant avec un id (modif), un composant sans id
	 *                  (crÃ©er)
	 */
	private void showVueComposant(Facade facade, Composant composant) {
		// bundle
		ResourceBundle bundle;
		// CrÃ©e une stage
		Stage stage = new Stage();
		// indique sa stage parent
		stage.initOwner(mainStage);
		stage.setX(150);
		stage.setY(200);

		// CrÃ©e un loader pour charger la vue FXML
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/composant/VueComposant.fxml"));
		try {
			bundle = ResourceBundle.getBundle("view.composant.bundle.VueComposant");
			loader.setResources(bundle);
			// Obtenir la traduction du titre dans la locale
			stage.setTitle(bundle.getString("composant.titre"));
		} catch (Exception e) {
			logger.error("Imposible de charger le buddle pour la vue Composant" + e.getMessage());
			showErreur("Impossible de charger le buddle ");
			stage.setTitle("Vue Composant");
		}
		// Charge la vue Ã  partir du Loader
		// et initialise son contenu en appelant la mÃ©thode setUp du controleur
		AnchorPane root;
		try {
			root = loader.load();
			// rÃ©cupÃ¨re le ctrl (aprÃ¨s l'initialisation)
			VueComposantController ctrl = loader.getController();
			// fourni la fabrique au ctrl pour charger les articles
			ctrl.setUp(facade, composant, stage);
			// charge le Pane dans la Stage
			Scene scene = new Scene(root, 600, 500);
			scene.getStylesheets().add("./view/css/composant.css");
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			logger.error("Imposible de charger la vue Composant");
			showErreur("Impossible de charger la vue Composant: " + e.getMessage());
			stage = null;
		}

	}

	/**
	 * Permet d'afficher la liste des composants et d'effectuer des suppressions
	 * 
	 * @param facade
	 */
	private void showVueListeComposant(Facade facade) {

		ResourceBundle bundle;
		// CrÃ©e une stage
		Stage stage = new Stage();
		// indique sa stage parent
		stage.initOwner(mainStage);

		stage.setX(150);
		stage.setY(200);

		// CrÃ©e un loader pour charger la vue FXML
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/composant/VueListeComposants.fxml"));
		try {
			bundle = ResourceBundle.getBundle("view.composant.bundle.VueListeComposants");
			
			loader.setResources(bundle);
			// Obtenir la traduction du titre dans la locale
			stage.setTitle(bundle.getString("composant.titre"));
		} catch (Exception e) {
			logger.error("Imposible de charger le bundle pour la vue listeComposant" + e.getMessage());
			showErreur("Impossible de charger le bundle ListeComposant");
			stage.setTitle("Vue Liste Composants");
		}
		// Charge la vue Ã  partir du Loader
		// et initialise son contenu en appelant la mÃ©thode setUp du controleur
		BorderPane root;
		try {
			root = loader.load();
			// rÃ©cupÃ¨re le ctrl (aprÃ¨s l'initialisation)
			VueListeComposantsController ctrl = loader.getController();
			// fourni la fabrique au ctrl pour charger les articles
			ctrl.setUp(facade);
			// charge le Pane dans la Stage
			Scene scene = new Scene(root, 400, 400);
			scene.getStylesheets().add("./view/css/composant.css");
			stage.setScene(scene);
			stage.show();
			// Se dÃ©sabonne lors de la fermeture
			stage.setOnCloseRequest(e -> {
				ctrl.getSubscription().cancel();
				logger.info(" Liste de composants: DÃ©sabonnement des Ã©vÃ¨nements ");
			});
		} catch (IOException e) {
			logger.error("Imposible de charger la vue ListeComposants");
			showErreur("Impossible de charger la vue ListeComposants: " + e.getMessage());
			stage = null;
		}

	}

	/**
	 * Vue pour afficher les messages d'erreur
	 * 
	 * @param message
	 */
	private void showErreur(String message) {
		Alert a = new Alert(AlertType.ERROR, message);
		a.showAndWait();
	}

	/**
	 * Point d'entrÃ©e principal de l'application
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
