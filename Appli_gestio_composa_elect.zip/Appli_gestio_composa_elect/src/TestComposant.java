import java.sql.Connection;
import java.util.Optional;

import dao.DAOFactory;
import dao.DAOFactory.TypePersistance;
import databases.connexion.ConnexionFromFile;
import databases.connexion.ConnexionSingleton;
import databases.connexion.IConnexionInfos;
import databases.uri.Databases;
import model.Composant;

public class TestComposant {

	public static void main(String[] args) {
		DAOFactory factory = null;
		try {
			IConnexionInfos info = new ConnexionFromFile("ressources/connexionComposant.properties",
					Databases.FIREBIRD);
			ConnexionSingleton.setInfoConnexion(info);
			Connection connect = ConnexionSingleton.getConnexion();

			// Crée la factory Firebird
			factory = DAOFactory.getDAOFactory(TypePersistance.FIREBIRD, connect);
			
				
		} catch (Exception e) {

		}
		
		Optional<Composant> c1=factory.getComposantDAO().getFromID(1);
		c1.ifPresent((c)->System.out.println(c));
		ConnexionSingleton.liberationConnexion();
	}

}
