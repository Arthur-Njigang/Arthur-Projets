package databases.connexion;

import java.util.Properties;

import databases.uri.Databases;

public class InfoEmployeeEcole implements IConnexionInfos {

	@Override
	public Properties getProperties() {
		Properties prop=new Properties();
		prop.setProperty("login", "etudiant");
		prop.setProperty("password", "isfce");
		prop.setProperty("charset", "iso8859_1");
		prop.setProperty("url", 
				Databases.FIREBIRD.buildServeurURL("employee", "192.168.0.5"));
		
		return prop;
	}

}
