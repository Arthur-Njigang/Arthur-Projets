package databases.uri;

public class Test {

	public static void main(String[] args) {

		String url1 = Databases.H2.buildServeurURL("~db1", "localhost");
		System.out.println(url1);

		String url2 = Databases.H2.buildServeurURL("~db1", "localhost", 3000);
		System.out.println(url2);

		 System.out.println(Databases.FIREBIRD.buildServeurURL("employee",
		 "192.168.0.5"));
		// System.out.println(Databases.H2.getDbUrl().buildServeurURL("employee",
		// "192.168.0.5"));
	}

}
