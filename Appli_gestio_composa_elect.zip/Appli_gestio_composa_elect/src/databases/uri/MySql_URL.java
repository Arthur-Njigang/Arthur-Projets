package databases.uri;

public class MySql_URL implements IDbURL {

	@Override
	public String getUrl() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String buildMemURL(String file) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String buildEmbeddedURL(String file) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String buildServeurURL(String file, String ip) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String buildServeurURL(String file, String ip, int port) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getDefaultPort() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean hasMemoryMode() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean hasEmbeddedMode() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean hasServeurMode() {
		// TODO Auto-generated method stub
		return false;
	}

}
