package dao;

import java.util.List;
import java.util.Optional;

import model.Composant;

public interface IComposantDAO extends IDAO<Composant, Integer> {
	boolean deleteFromId(Integer id) throws Exception;
	/**
	 * Charge un composant à partir d'une référence (ne charge pas ses détails)
	 * 
	 * @param ref le référence du composant (unique)
	 * @return un optional de composant
	 */
	Optional<Composant> getFromRef(String ref);

	/**
	 * Charge tous les composants du type précisé (ne charge pas les détails des
	 * composants)
	 * 
	 * @param typeC le type de composant
	 * @return une liste
	 */
	List<Composant> getFromType(String typeC);
}
