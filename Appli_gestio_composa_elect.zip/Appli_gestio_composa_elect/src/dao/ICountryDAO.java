package dao;

import java.util.List;

import model.Country;

public interface ICountryDAO extends IDAO<Country, String> {
	/**
	 * Obtenir la liste des pays pour une devise
	 * @param devise
	 * @return liste des pays
	 */
	List<Country> getCountryFromDevise(String devise);
}
