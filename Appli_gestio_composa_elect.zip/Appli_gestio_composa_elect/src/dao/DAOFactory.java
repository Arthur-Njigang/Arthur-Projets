package dao;

import java.sql.Connection;
import java.sql.SQLException;

import dao.exception.ComposantException;

public abstract class DAOFactory {

	public enum TypePersistance {
		FIREBIRD, H2, XML
	}

	public abstract ICountryDAO getCountryDAO();

	public abstract IComposantDAO getComposantDAO();

	public static DAOFactory getDAOFactory(TypePersistance typeP, Connection connect) {
		switch (typeP) {
		case FIREBIRD:
			return new FBDAOFactory(connect);

		default:
			return null;
		}
	}

	public abstract Connection getConnection();

	protected abstract void dispatchException(Exception e) throws ComposantException;
	
	public abstract IInformationDAO getInformationDAO();
	
	public abstract IProprieteDAO getProprieteDAO();
	
	public abstract ITypeComposantDAO getTypeComposantDAO();

}
