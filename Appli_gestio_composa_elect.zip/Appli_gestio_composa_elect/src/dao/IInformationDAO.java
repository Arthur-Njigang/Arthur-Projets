package dao;

import java.util.List;

import model.Composant;
import model.IdInformation;
import model.Information;

public interface IInformationDAO extends IDAO<Information, IdInformation>{
	
	/**
	 * 
	 */
	
	List<Information> getListeFromComposant(Composant composant);
}
