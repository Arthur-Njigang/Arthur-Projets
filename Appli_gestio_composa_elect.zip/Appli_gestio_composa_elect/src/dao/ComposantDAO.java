package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import dao.exception.ComposantDoublonException;
import dao.exception.ComposantException;
import model.Composant;
import model.Country;

public class ComposantDAO implements IComposantDAO {
	private final static String SQL_FROM_ID = """
			SELECT  a.REF_COM, a.QT_COM, a.PRIX_COM, a.LOC_COM, a.FKTYPE_COM
			FROM TCOMPOSANT a
			WHERE a.ID_COM = ?
			""";

	private Connection connection;
	private DAOFactory fabrique;

	/**
	 * @param fabrique
	 */
	public ComposantDAO(DAOFactory fabrique) {
		this.fabrique = fabrique;
		this.connection = fabrique.getConnection();
	}

	@Override
	public Optional<Composant> getFromID(Integer id) {
		Composant composant = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_ID)) {
			ps.setInt(1, id);
			var rs = ps.executeQuery();
			if (rs.next())
				composant = new Composant(id, rs.getString(1), rs.getInt(2), rs.getDouble(3), rs.getString(4),
						rs.getString(5));
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return Optional.ofNullable(composant);

	}

	@Override
	public List<Composant> getListe(String regExpr) {
		List<Composant> composants = new ArrayList<Composant>();
		
		String SQL_FROM_REF = "";
		
		if(regExpr == null) {
			SQL_FROM_REF = """
					SELECT  ID_COM, REF_COM, QT_COM, PRIX_COM, LOC_COM, FKTYPE_COM
					FROM TCOMPOSANT
					""";
		}else {
			SQL_FROM_REF = """
					SELECT  a.ID_COM, a.REF_COM, a.QT_COM, a.PRIX_COM, a.LOC_COM, a.FKTYPE_COM
					FROM TCOMPOSANT a
					WHERE a.ID_COM like '?'
					""";
		}
		
		Composant composant = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			if(regExpr != null)
				ps.setString(1, regExpr);
			var rs = ps.executeQuery();
			while (rs.next()) {
				composant = new Composant(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getDouble(4), rs.getString(5),
						rs.getString(6));
				composants.add(composant);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return composants;
	}
	
	/**
	 * insert un element dans la table TComposant 
	 * 
	 * @param : Composant a inserer
	 * @return : Comosant ajouter ou null si le composnt n'a pu etre ajouter
	 */

	@Override
	public Composant insert(Composant objet) throws Exception {
		Optional<Composant> cRetour = getFromRef(objet.getRef());
		if(cRetour.isPresent()) {
			throw (new ComposantDoublonException("Doublon detected", objet.getRef()));
		}
		
		String SQL_FROM_INSERT ="""
				INSERT INTO TCOMPOSANT(REF_COM, QT_COM, PRIX_COM, LOC_COM, FKTYPE_COM) VALUES(?, ?, ?, ?, ?)
				""";
		//ID_COM
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_INSERT)) {
			ps.setString(1, objet.getRef());
			ps.setInt(2, objet.getQt());
			ps.setDouble(3, objet.getPrix());
			ps.setString(4, objet.getLocalisation());
			ps.setString(5, objet.getTypeCmp());
			
			if(ps.executeUpdate() > 0) {
				Optional<Composant> cRetour_ = getFromRef(objet.getRef());
				if(cRetour_.isPresent()) {
					return cRetour_.get();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * supprime un composant dans la table TComposant 
	 * 
	 * @param : Composant a supprimer
	 * @return : vrai si le composant est supprimer faux sinon
	 */
	@Override
	public boolean delete(Composant object) throws Exception {
		// TODO Auto-generated method stub
		return deleteFromId(object.getId());
	}
	
	/**
	 * Met un composant a jour connaissant son identifiant
	 * 
	 * @param : Composant a actualiser
	 * @return : vrai si la mise a jour es effective
	 */

	@Override
	public boolean update(Composant object) throws Exception {
		String SQL_FROM_REF = """
				UPDATE  TCOMPOSANT set REF_COM = ?, QT_COM = ?, PRIX_COM = ?, LOC_COM = ?, FKTYPE_COM = ?
				WHERE ID_COM= ?
				""";
		
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			ps.setInt(6, object.getId());
			ps.setString(1, object.getRef());
			ps.setInt(2, object.getQt());
			ps.setDouble(3, object.getPrix());
			ps.setString(4, object.getLocalisation());
			ps.setString(5, object.getTypeCmp());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		};
		
		return true;
	}
	
	/**
	 * reccuper un composant connaissant ca reference
	 * 
	 * @param : ref qui est la reference au composant
	 * @return : Comosant trouver
	 */

	@Override
	public Optional<Composant> getFromRef(String ref) {
		
		String SQL_FROM_REF = """
				SELECT  a.ID_COM, a.QT_COM, a.PRIX_COM, a.LOC_COM, a.FKTYPE_COM
				FROM TCOMPOSANT a
				WHERE a.REF_COM= ?
				""";
		
		Composant composant = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			ps.setString(1, ref);
			var rs = ps.executeQuery();
			if (rs.next()) {
				composant = new Composant(rs.getInt(1), ref, rs.getInt(2), rs.getDouble(3), rs.getString(4),
						rs.getString(5));
				ps.executeQuery();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return Optional.ofNullable(composant);
	}
	
	/**
	 * reccuper une liste de composant connaissant leurs types commun
	 * 
	 * @param : type du composant
	 * @return : liste des composants de ce type la
	 */

	@Override
	public List<Composant> getFromType(String typeC) {
		List<Composant> composants = new ArrayList<Composant>();
		
		String SQL_FROM_REF = """
				SELECT  a.ID_COM, a.REF_COM, a.QT_COM, a.PRIX_COM, a.LOC_COM
				FROM TCOMPOSANT a
				WHERE a.FKTYPE_COM= ?
				""";
		
		Composant composant = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			ps.setString(1, typeC);
			var rs = ps.executeQuery();
			while (rs.next()) {
				composant = new Composant(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getDouble(4), rs.getString(5),
						typeC);
				composants.add(composant);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return composants;
	}
	
	/**
	 * supprime un composant connaissant son id
	 * 
	 * @param : Composant a inserer
	 * @return : Comosant ajouter ou null si le composnt n'a pu etre ajouter
	 */

	@Override
	public boolean deleteFromId(Integer id) throws Exception {
		String SQL_FROM_REF = """
				DELETE FROM TCOMPOSANT
				WHERE ID_COM= ?
				""";
		
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	/**
	 * reccupere le nombre de composant dans la base de donnee ou dans la table TComposant
	 * 
	 * @param : 
	 * @return : nombre de composants dans la table TComposant
	 */
	
	@Override
	public int count() {
		String SQL_FROM_REF = """
				SELECT COUNT(*) FROM TCOMPOSANT
				""";
		
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			ResultSet rs = ps.executeQuery();
			if(rs.next())
				return rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

}
