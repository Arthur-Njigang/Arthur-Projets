package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import model.Propriete;
import model.TypeComposant;
import model.TypeP;

public class TypeComposantDAO implements ITypeComposantDAO {

	private Connection connection;
	private DAOFactory fabrique;

	/**
	 * @param fabrique
	 */
	public TypeComposantDAO(DAOFactory fabrique) {
		this.fabrique = fabrique;
		this.connection = fabrique.getConnection();
	}
	
	@Override
	public Optional<TypeComposant> getFromID(String id) {
		// TODO Auto-generated method stub
		String SQL_FROM_ID = """
				SELECT  a.CODE_TYP, a.NOM_TYP
				FROM TTYPE a
				WHERE a.CODE_TYP = ?
				""";
		
		TypeComposant typeComposant = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_ID)) {
			ps.setString(1, id);
			var rs = ps.executeQuery();
			ProprieteDAO proprieteDAO = new ProprieteDAO(fabrique);
			if (rs.next()) {
				List<Propriete> listProp = proprieteDAO.getListe(null);
				if(listProp != null && listProp.size() > 0) {
					String type_iinfo = rs.getString(1);
					for(int i = 0; i < listProp.size(); i++){
						if(listProp.get(i).getTypeP().name() != type_iinfo) {
							listProp.remove(i);
							i--;
						}
					}
				}
				typeComposant = new TypeComposant(rs.getString(1), rs.getString(2), listProp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return Optional.ofNullable(typeComposant);
	}

	@Override
	public List<TypeComposant> getListe(String regExpr) {
		List<TypeComposant> typeComposants = new ArrayList<TypeComposant>();
		
		String SQL_FROM_REF = "";
		
		if(regExpr == null) {
			SQL_FROM_REF = """
								SELECT  CODE_TYP, NOM_TYP
								FROM TTYPE
						   """;
		}else {
			SQL_FROM_REF = """
								SELECT  a.CODE_TYP, a.NOM_TYP
								FROM TTYPE a
								WHERE a.CODE_TYP = '?'
							""";
		}
		
		TypeComposant typeComposant = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			if(regExpr != null)
				ps.setString(1, regExpr);
			var rs = ps.executeQuery();
			while (rs.next()) {
				ProprieteDAO proprieteDAO = new ProprieteDAO(fabrique);
				List<Propriete> listProp = new ArrayList<Propriete>();// a retravaille
				
				typeComposant = new TypeComposant(rs.getString(1), rs.getString(2), listProp);
				typeComposants.add(typeComposant);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return typeComposants;
	}

	@Override
	public List<TypeComposant> getListeRef() {
		// TODO Auto-generated method stub
		List<TypeComposant> typeComposants = getListe(null);
		typeComposants.sort(new SortedTypeComposant());
		return typeComposants;
	}


	class SortedTypeComposant implements Comparator<TypeComposant>{
		@Override
		public int compare(TypeComposant o1, TypeComposant o2) {
			// TODO Auto-generated method stub
			return o1.getCode().compareTo(o2.getCode());
		}
		
	}
}
