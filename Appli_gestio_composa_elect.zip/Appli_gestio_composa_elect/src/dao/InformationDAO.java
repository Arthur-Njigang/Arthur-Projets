package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import dao.exception.ComposantDoublonException;
import model.Composant;
import model.IdInformation;
import model.Information;

public class InformationDAO implements IInformationDAO {
	
	private Connection connection;
	private DAOFactory fabrique;

	/**
	 * @param fabrique
	 */
	public InformationDAO(DAOFactory fabrique) {
		this.fabrique = fabrique;
		this.connection = fabrique.getConnection();
	}

	@Override
	public Information insert(Information objet) {
		String SQL_FROM_REF = """
				INSERT INTO TINFO(FKCOMPOSANT_INF, FKPROPRIETE_INF, VALEUR_INF, UNITE_INF) VALUES(?, ?, ?, ?)
				""";
		
		Information information = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			ps.setInt(1, objet.getIdInformation().getComposant());
			ps.setString(2, objet.getIdInformation().getPropriete());
			ps.setString(3, objet.getValeur());
			ps.setString(4, objet.getUnite());

			if(ps.executeUpdate() <= 0) {
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return objet;
	}

	@Override
	public boolean delete(Information information) {
		String SQL_FROM_REF = """
				DELETE FROM TINFO
				WHERE FKCOMPOSANT_INF= ? AND FKPROPRIETE_INF = ?
				""";
		
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			ps.setInt(1, information.getIdInformation().getComposant());
			ps.setString(2, information.getIdInformation().getPropriete());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public boolean update(Information information) {
		String SQL_FROM_REF = """
				UPDATE  TINFO set VALEUR_INF = ?, UNITE_INF = ?
				WHERE FKCOMPOSANT_INF = ? AND FKPROPRIETE_INF = ?
				""";
		
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {

			ps.setString(1, information.getValeur());
			ps.setString(2, information.getUnite());
			ps.setInt(3, information.getIdInformation().getComposant());
			ps.setString(4, information.getIdInformation().getPropriete());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		};
		
		return true;
	}

	@Override
	public List<Information> getListeFromComposant(Composant composant) {
		List<Information> informations = new ArrayList<Information>();
		
		String SQL_FROM_REF = """
				SELECT  a.FKCOMPOSANT_INF, a.FKPROPRIETE_INF, a.VALEUR_INF, a.UNITE_INF
				FROM TINFO a
				WHERE a.FKCOMPOSANT_INF = ?
				""";
		
		Information information = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			ps.setInt(1, composant.getId());
			var rs = ps.executeQuery();
			while (rs.next()) {
				information = new Information(new IdInformation(rs.getInt(1), rs.getString(2)), rs.getString(3), rs.getString(4));
				informations.add(information);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return informations;
	}

}
