package dao;

import java.sql.Connection;
import java.sql.SQLException;

import dao.exception.ComposantException;
import dao.exception.ComposantDoublonException;

public class FBDAOFactory extends DAOFactory {

	private Connection connection;
	private ICountryDAO daoCountry = null;

	private IComposantDAO daoComposant = null;
	
	private IInformationDAO daoInformation = null;
	
	private IProprieteDAO daoPropriete = null;
	
	private ITypeComposantDAO daoTypeComposant = null;

	public FBDAOFactory(Connection connect) {
		this.connection = connect;
	}

	@Override
	public ICountryDAO getCountryDAO() {
		if (daoCountry == null)
			this.daoCountry = new CountryDAO(this);
		return daoCountry;
	}

	@Override
	public IComposantDAO getComposantDAO() {
		if (daoComposant == null)
			this.daoComposant = new ComposantDAO(this);
		return daoComposant;
	}

	@Override
	protected void dispatchException(Exception e) throws ComposantException {
		if (e instanceof SQLException esql) {
			throw switch (esql.getErrorCode()) {
			case 335544665:
				yield new ComposantDoublonException("Problème de PK", "????");

			default:
				yield new ComposantException(" Problème bd employee");

			};
		}
	}

	@Override
	public Connection getConnection() {
		return this.connection;
	}

	@Override
	public IInformationDAO getInformationDAO() {
		// TODO Auto-generated method stub
		if (daoInformation == null)
			this.daoInformation = new InformationDAO(this);
		return daoInformation;
	}

	@Override
	public IProprieteDAO getProprieteDAO() {
		// TODO Auto-generated method stub
		if (daoPropriete == null)
			this.daoPropriete = new ProprieteDAO(this);
		return daoPropriete;
	}

	@Override
	public ITypeComposantDAO getTypeComposantDAO() {
		// TODO Auto-generated method stub
		if (daoTypeComposant == null)
			this.daoTypeComposant = new TypeComposantDAO(this);
		return daoTypeComposant;
	}
}
