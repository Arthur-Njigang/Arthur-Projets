package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import model.Composant;
import model.Propriete;
import model.TypeP;

public class ProprieteDAO implements IProprieteDAO {
	
	private final static String SQL_FROM_ID = """
			SELECT  a.NOM_PRO, a.OBLIGATOIRE_PRO, a.LISTECHOIX_PRO, a.LISTEUNITE_PRO, a.TYPE_PRO, a.FKTYPE_PRO
			FROM TPROPRIETE a
			WHERE a.NOM_PRO = ?
			""";
	
	private final static String SQL_FROM_TYPE = """
			SELECT  a.NOM_PRO, a.OBLIGATOIRE_PRO, a.LISTECHOIX_PRO, a.LISTEUNITE_PRO, a.TYPE_PRO, a.FKTYPE_PRO
			FROM TPROPRIETE a
			WHERE a.TYPE_PRO = ?
			""";
	
	private Connection connection;
	private DAOFactory fabrique;

	/**
	 * @param fabrique
	 */
	public ProprieteDAO(DAOFactory fabrique) {
		this.fabrique = fabrique;
		this.connection = fabrique.getConnection();
	}

	@Override
	public Optional<Propriete> getFromID(String id) {
		// TODO Auto-generated method stub
		Propriete propriete = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_ID)) {
			ps.setString(1, id);
			var rs = ps.executeQuery();
			if (rs.next()) {
				List<String> listChoix = new ArrayList<String>();
				listChoix.add(rs.getString(3));
				List<String> listUnite = new ArrayList<String>();
				listUnite.add(rs.getString(4));
				
				TypeP typeP = TypeP.valueOf(rs.getString(5));
				
				propriete = new Propriete(rs.getString(1), rs.getBoolean(2), listChoix, listUnite, typeP, rs.getString(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return Optional.ofNullable(propriete);
	}

	@Override
	public List<Propriete> getListe(String regExpr) {
		List<Propriete> proprietes = new ArrayList<Propriete>();
		
		String SQL_FROM_REF = "";
		if(regExpr == null) {
			SQL_FROM_REF = """
					SELECT  NOM_PRO, OBLIGATOIRE_PRO, LISTECHOIX_PRO, LISTEUNITE_PRO, TYPE_PRO, FKTYPE_PRO
					FROM TPROPRIETE
					""";
		}else {
			SQL_FROM_REF = """
					SELECT  a.NOM_PRO, a.OBLIGATOIRE_PRO, a.LISTECHOIX_PRO, a.LISTEUNITE_PRO, a.TYPE_PRO, a.FKTYPE_PRO
					FROM TPROPRIETE a
					WHERE a.NOM_PRO like '?'
					""";
		}
		
		Propriete propriete = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			if(regExpr != null)
				ps.setString(1, regExpr);
			var rs = ps.executeQuery();
			while (rs.next()) {
				List<String> listChoix = new ArrayList<String>();
				for(String s : rs.getString(3).split(";")) {
					listChoix.add(s);
				}
				List<String> listUnite = new ArrayList<String>();
				for(String s : rs.getString(4).split(";")) {
					listUnite.add(s);
				}
				
				TypeP typeP = TypeP.valueOf(rs.getString(5));
				
				propriete = new Propriete(rs.getString(1), rs.getBoolean(2), listChoix, listUnite, typeP, rs.getString(6));
				proprietes.add(propriete);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return proprietes;
	}

	@Override
	public List<Propriete> getListeForType(TypeP typeP) {
		// TODO Auto-generated method stub
		List<Propriete> liste = new ArrayList<Propriete>();
		Propriete propriete = null;
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_TYPE)) {
			ps.setString(1, typeP.name());
			var rs = ps.executeQuery();
			while (rs.next()) {
				List<String> listChoix = new ArrayList<String>();
				for(String s : rs.getString(3).split(";")) {
					listChoix.add(s);
				}
				List<String> listUnite = new ArrayList<String>();
				for(String s : rs.getString(4).split(";")) {
					listUnite.add(s);
				}
				
				propriete = new Propriete(rs.getString(1), rs.getBoolean(2), listChoix, listUnite, typeP, rs.getString(6));
				
				liste.add(propriete);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return liste;
	}
	
	@Override
	public List<Propriete> getListeForType(String fkTypeP) {
		// TODO Auto-generated method stub
		List<Propriete> liste = new ArrayList<Propriete>();
		Propriete propriete = null;
		String SQL_FROM_REF = """
				SELECT  a.NOM_PRO, a.OBLIGATOIRE_PRO, a.LISTECHOIX_PRO, a.LISTEUNITE_PRO, a.TYPE_PRO, a.FKTYPE_PRO
				FROM TPROPRIETE a
				WHERE a.FKTYPE_PRO = ?
				""";
		try (PreparedStatement ps = connection.prepareStatement(SQL_FROM_REF)) {
			ps.setString(1, fkTypeP);
			var rs = ps.executeQuery();
			while (rs.next()) {
				List<String> listChoix = new ArrayList<String>();
				if(rs.getString(3) != null) {
					for(String s : rs.getString(3).split(";")) {
						listChoix.add(s);
					}
				}
				List<String> listUnite = new ArrayList<String>();
				
				if(rs.getString(4) != null) {
					for(String s : rs.getString(4).split(";")) {
						listUnite.add(s);
					}
				}
				
				propriete = new Propriete(rs.getString(1), rs.getBoolean(2), listChoix, listUnite, TypeP.valueOf(rs.getString(5))
											, rs.getString(6));
				
				liste.add(propriete);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return liste;
	}

}
