package dao;

import java.util.List;
import java.util.Optional;

import model.Composant;
import model.Propriete;
import model.TypeP;

public interface IProprieteDAO  extends IDAO<Propriete, String> {
	
	/**
	 * il va permettre de recupérer une prpriete connaissant son id
	 * 
	 * @param Expression régulière à appliquer sur l'ID. 
	 * 		  null: pas de condition
	 * @return une propriete si elle existe ou si elle n'existe pas
	 */
	
	List<Propriete> getListeForType(TypeP typeP);

	List<Propriete> getListeForType(String fkTypeP);
}
