package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import model.Country;

public class CountryDAO implements ICountryDAO {
	private static final String SQLGETFROMID = "SELECT * FROM COUNTRY WHERE COUNTRY=?";
	private static final String SQLINSERT = "INSERT INTO COUNTRY VALUES(?,?) RETURNING COUNTRY";

	private Connection connection;
	private DAOFactory factory;

	/**
	 * @param connection
	 */
	public CountryDAO(DAOFactory factory) {
		this.factory = factory;
		this.connection = factory.getConnection();
	}

	@Override
	public int count() {
		int res = 0;
		try (var st = connection.createStatement();) {
			var rs = st.executeQuery("select count(*) from Country");
			rs.next();
			res = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public List<Country> getCountryFromDevise(String devise) {

		List<Country> liste = new ArrayList<>();
		try (PreparedStatement ps = connection.prepareStatement("select COUNTRY from country where CURRENCY = ?")) {
			ps.setString(1, devise);
			var rs2 = ps.executeQuery();
			while (rs2.next()) {
				liste.add(new Country(rs2.getString("COUNTRY"), devise));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return liste;
	}

	@Override
	public Optional<Country> getFromID(String id) {
		Country country = null;
		try (PreparedStatement ps = connection.prepareStatement(SQLGETFROMID)) {
			ps.setString(1, id);
			var rs2 = ps.executeQuery();
			if (rs2.next())
				country = new Country(id, rs2.getString("CURRENCY"));
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return Optional.ofNullable(country);
	}

	@Override
	public Country insert(Country c) throws Exception {
		try (PreparedStatement ps = connection.prepareStatement(SQLINSERT)) {
			ps.setString(1, c.getNom());
			ps.setString(2, c.getDevise());
			var rs2 = ps.executeQuery();// CAR Returning
			if (rs2.next())
				c.setNom(rs2.getString(1));
		} catch (SQLException e) {
			this.factory.dispatchException(e);
		}
		return c;
	}

}
