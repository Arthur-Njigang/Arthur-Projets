package dao.exception;

public class ComposantDoublonException extends ComposantException {

	private static final long serialVersionUID = 1L;
	
	private String nom;

	public ComposantDoublonException(String message, String nom) {
		super(message);
		this.nom = nom;
	}

	public String getNom() {
		return nom;
	}

}
