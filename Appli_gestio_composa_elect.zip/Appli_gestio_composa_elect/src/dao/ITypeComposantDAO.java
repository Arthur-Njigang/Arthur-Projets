package dao;

import java.util.List;
import java.util.Optional;

import model.Composant;
import model.TypeComposant;
import model.TypeP;

public interface ITypeComposantDAO  extends IDAO<TypeComposant, String> {
	List<TypeComposant> getListeRef();
}
