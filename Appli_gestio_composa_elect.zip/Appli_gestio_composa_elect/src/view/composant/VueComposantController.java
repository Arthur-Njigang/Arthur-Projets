package view.composant;

import java.net.URL;
import java.util.ResourceBundle;

import dao.exception.ComposantException;
import dao.exception.ComposantDoublonException;
import javafx.collections.FXCollections;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Composant;
import service.Facade;

public class VueComposantController implements Initializable {
	// pseudo classe pour les erreurs
	private final PseudoClass errorClass = PseudoClass.getPseudoClass("error");

	@FXML
	private Button btAnnuler;

	@FXML
	private Button btOk;

	@FXML
	private TextField ztId;

	@FXML
	private TextField ztPrix;

	@FXML
	private TextField ztQt;

	@FXML
	private TextField ztRef;
	
	@FXML
	private TextField ztQtu; // quatité unité

	@FXML
	private TextField ztPt; // prix total

	@FXML
	private TextField ztPu; // prix unité

	@FXML
	private TextField ztLocalisation;

	@FXML
	private ComboBox<String> cbTypeC;

	private Composant cmp;

	private Facade facade;

	private Stage stage;

	private ResourceBundle bundle;

	private boolean nouveau;

	@FXML
	void annuler(ActionEvent event) {
		stage.hide();
	}

	@FXML
	void valider(ActionEvent event) {
		boolean bad = false;
		boolean erreur;

		erreur = ztRef.getText().isBlank();
		ztRef.pseudoClassStateChanged(errorClass, erreur);
		bad = bad || erreur;

		erreur = ztQt.getText().isBlank();
		ztQt.pseudoClassStateChanged(errorClass, erreur);
		bad = bad || erreur;

		erreur = ztPrix.getText().isBlank();
		ztPrix.pseudoClassStateChanged(errorClass, erreur);
		bad = bad || erreur;

		erreur = ztLocalisation.getText().isBlank();
		ztLocalisation.pseudoClassStateChanged(errorClass, erreur);
		bad = bad || erreur;

		erreur = cbTypeC.getValue() == null;
		cbTypeC.pseudoClassStateChanged(errorClass, erreur);
		bad = bad || erreur;

		if (!bad) {
			try {
				if (!nouveau) {
					cmp.setRef(ztRef.getText());
					cmp.setQt(Integer.parseInt(ztQt.getText()));
					cmp.setPrix(Double.parseDouble(ztPrix.getText()));
					cmp.setLocalisation(ztLocalisation.getText());
					facade.updateComposant(cmp);
				} else
					facade.createComposant(new Composant(null, ztRef.getText(), Integer.parseInt(ztQt.getText()),
							Double.parseDouble(ztPrix.getText()), ztLocalisation.getText(), cbTypeC.getValue()));
				stage.hide();
			} catch (NumberFormatException e) {
				showErreur("Problème de conversion");
			} catch (ComposantException e) {
				if (e instanceof ComposantDoublonException pkexc)// Si c'est un problème de doublon qui est en cause
					ztRef.pseudoClassStateChanged(errorClass, true);

				showErreur(e.getMessage());
			}
		}
	}

	/**
	 * Crée ou modifie un composant
	 * 
	 * @param facade
	 * @param cmp    le composant ou null pour créer un nouveau
	 * @param stage
	 */
	public void setUp(Facade facade, Composant cmp, Stage stage) {
		this.cmp = cmp;
		this.facade = facade;
		this.stage = stage;
		this.nouveau = cmp == null;
		if (cmp != null) {
			// maj de la vue
			ztId.setText(cmp.getId() == null ? "" : cmp.getId().toString());
			ztRef.setText(cmp.getRef() == null ? "" : cmp.getRef());
			ztQt.setText(Integer.toString(cmp.getQt()));
			ztPrix.setText(Double.toString(cmp.getPrix()));
			ztLocalisation.setText(cmp.getLocalisation());
			cbTypeC.setItems(FXCollections.observableArrayList(facade.getListeTypesComposant()));
			cbTypeC.setValue(cmp.getTypeCmp());
			cbTypeC.setDisable(true);
		} else // nouveau composant
		{
			ztId.setText("");
			ztRef.setText("");
			ztQt.setText("0");
			ztPrix.setText("0.0");
			ztLocalisation.setText("R.E.C.B..");
			cbTypeC.setItems(FXCollections.observableList(facade.getListeTypesComposant()));
			// cbTypeC.setValue(cmp.getTypeCmp());
			cbTypeC.setDisable(false);
		}

	}

	@Override
	public void initialize(URL arg0, ResourceBundle bundle) {
		this.bundle = bundle;
		// Permet d'encoder uniquement un entier
		ztQt.textProperty().addListener((obs, oldV, newV) -> {
			try {
				if (newV.length() > 0)
					Integer.parseInt(newV);
			} catch (Exception e) {
				// si une exception est générée, on remet l'ancienne valeur
				ztQt.setText(oldV);
			}
		});
		// Permet d'avoir uniquement un double
		ztPrix.textProperty().addListener((obs, oldV, newV) -> {
			try {
				if (newV.length() > 0)
					Double.parseDouble(newV);
			} catch (Exception e) {
				// si une exception est générée, on remet l'ancienne valeur
				ztPrix.setText(oldV);
			}
		});
		/*
		 * .addListener(new ChangeListener<String>() {
		 * 
		 * @Override public void changed(ObservableValue<? extends String> observable,
		 * String oldValue, String newValue) { try {// Teste si la chaine possède
		 * possède au moins un caractère et si on peut la parser
		 * 
		 * 
		 * }} });
		 */
		
		// Permet d'encoder uniquement un entier
				ztQtu.textProperty().addListener((obs, oldV, newV) -> {
					try {
						if (newV.length() > 0)
							Integer.parseInt(newV);
					} catch (Exception e) {
						// si une exception est générée, on remet l'ancienne valeur
						ztQtu.setText(oldV);
					}
				});
				// Permet d'avoir uniquement un double
				ztPt.textProperty().addListener((obs, oldV, newV) -> {
					try {
						if (newV.length() > 0)
							Double.parseDouble(newV);
					} catch (Exception e) {
						// si une exception est générée, on remet l'ancienne valeur
						ztPt.setText(oldV);
					}
				});
				// Permet d'avoir uniquement un double
				ztPu.textProperty().addListener((obs, oldV, newV) -> {
					try {
						if (newV.length() > 0)
							Double.parseDouble(newV);
					} catch (Exception e) {
						// si une exception est générée, on remet l'ancienne valeur
						ztPu.setText(oldV);
					}
				});
	}

	private void showErreur(String message) {
		Alert a = new Alert(AlertType.ERROR, message);
		a.showAndWait();
	}
	
	@FXML
    void calculQuantiter(ActionEvent event) {
		boolean bad = false;
		boolean erreur;

		erreur = ztQtu.getText().isBlank();
		ztQtu.pseudoClassStateChanged(errorClass, erreur);
		bad = bad || erreur;

		erreur = ztPt.getText().isBlank();
		ztPt.pseudoClassStateChanged(errorClass, erreur);
		bad = bad || erreur;

		erreur = ztPu.getText().isBlank();
		ztPu.pseudoClassStateChanged(errorClass, erreur);
		bad = bad || erreur;

		if (!bad) {
			int value;
			int x = Integer.parseInt(ztQtu.getText());
			double y = Double.parseDouble(ztPt.getText());
			double z = Double.parseDouble(ztPu.getText());
			value = (int)( x * y / z);
			ztQt.setText(String.valueOf(value));
		}
    }

}
