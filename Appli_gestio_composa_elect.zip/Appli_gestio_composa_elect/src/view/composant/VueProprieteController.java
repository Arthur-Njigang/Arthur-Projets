package view.composant;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.util.Callback;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import javafx.stage.Stage;
import model.Composant;
import model.Propriete;
import model.TypeP;
import service.Facade;

public class VueProprieteController implements Initializable  {

	@FXML
    private Label ztRef;

    @FXML
    private Label ztCom;

    @FXML
    private TableView<Propriete> tableList;
    
    @FXML
    private TableColumn<Propriete, String> colNom;

    @FXML
    private TableColumn<Propriete, String> colValeur;

    @FXML
    private TableColumn<Propriete, String> colUnit;

    @FXML
    private TableColumn<Propriete, Boolean> colObligatoire;
    
    private Composant cmp;

	private Facade facade;

	private Stage stage;

	private ResourceBundle bundle;
	
	private ObservableList<Propriete> itemRoot;
	private List<Integer> update_pro = new ArrayList<Integer>();

    @FXML
    void annuler(ActionEvent event) {
    	stage.hide();
    }

    @FXML
    void valider(ActionEvent event) {
    	try {
    		if(update_pro != null) {
    			for(int i = 0; i < update_pro.size(); i++) {
    				this.facade.updatePropriete(itemRoot.get(update_pro.get(i)));
    			}
    		}
    		stage.hide();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		update_pro.clear();
		tableList.setEditable(true);
		
		colNom.setCellValueFactory(new PropertyValueFactory<Propriete, String>("nom"));
		
        colValeur.setCellValueFactory(new PropertyValueFactory<Propriete, String>("listeChoix"));
        colValeur.setCellFactory(TextFieldTableCell.forTableColumn());
        colValeur.setOnEditCommit((CellEditEvent<Propriete, String> event) -> {
            TablePosition<Propriete, String> pos = event.getTablePosition();

            String newFullName = event.getNewValue();

            int row = pos.getRow();
            Propriete propriete = event.getTableView().getItems().get(row);

            propriete.setListeChoix(newFullName);
            
            if(!update_pro.contains(row))update_pro.add(row);
        });
        
        colUnit.setCellValueFactory(new PropertyValueFactory<Propriete, String>("listeUnite"));
        colUnit.setCellFactory(TextFieldTableCell.forTableColumn());
        colUnit.setOnEditCommit((CellEditEvent<Propriete, String> event) -> {
            TablePosition<Propriete, String> pos = event.getTablePosition();

            String newFullName = event.getNewValue();

            int row = pos.getRow();
            Propriete propriete = event.getTableView().getItems().get(row);
            
            propriete.setListeUnite(newFullName);
            
            if(!update_pro.contains(row))update_pro.add(row);
        });
        
        colObligatoire.setCellValueFactory(new Callback<CellDataFeatures<Propriete, Boolean>, ObservableValue<Boolean>>() {

            @Override
            public ObservableValue<Boolean> call(CellDataFeatures<Propriete, Boolean> param) {
            	Propriete propriete = param.getValue();
            	
            	//TablePosition<Propriete, String> pos = param.getTablePosition();
            	
                SimpleBooleanProperty booleanProp = new SimpleBooleanProperty(propriete.isObligatoire());

                booleanProp.addListener(new ChangeListener<Boolean>() {

                    @Override
                    public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                    	
                    	propriete.setObligatoire(newValue);
                    	if(tableList.getItems().contains(propriete)) {
                    		int row = tableList.getItems().indexOf(propriete);
                    		if(!update_pro.contains(row) && row >= 0)update_pro.add(row);
                    	}
                    }
                });
                return booleanProp;
            }
        });
        colObligatoire.setCellFactory(new javafx.util.Callback<TableColumn<Propriete,Boolean>, TableCell<Propriete,Boolean>>() {
			
			@Override
			public TableCell<Propriete, Boolean> call(TableColumn<Propriete, Boolean> arg0) {
				CheckBoxTableCell<Propriete, Boolean> cell = new CheckBoxTableCell<Propriete, Boolean>();
                cell.setAlignment(Pos.CENTER);
                return cell;
			}
		});
        
        colObligatoire.setOnEditCommit((CellEditEvent<Propriete, Boolean> event) -> {
            TablePosition<Propriete, Boolean> pos = event.getTablePosition();

            Boolean newValue = event.getNewValue();

            int row = pos.getRow();
            Propriete propriete = event.getTableView().getItems().get(row);
            
            propriete.setObligatoire(newValue);
            
            System.out.print(newValue);
            
            if(!update_pro.contains(row))update_pro.add(row);
        });
        
        itemRoot = FXCollections.observableArrayList();
        
        tableList.setItems(itemRoot);
	}
	
	/**
	 * CrÃ©e ou modifie un composant
	 * 
	 * @param facade
	 * @param cmp    le composant ou null pour crÃ©er un nouveau
	 * @param stage
	 */
	public void setUp(Facade facade, Composant cmp, Stage stage) {
		this.cmp = cmp;
		this.facade = facade;
		this.stage = stage;
		//this.nouveau = cmp == null;
		if (cmp != null) {
			// maj de la vue
			ztRef.setText(cmp.getRef());
			ztCom.setText(cmp.getTypeCmp());
			
			List<Propriete> poprietes = this.facade.getDAOFactory().getProprieteDAO().getListeForType(this.cmp.getTypeCmp());
			itemRoot.addAll(poprietes);
		} /*else // nouveau composant
		{
			ztId.setText("");
			ztRef.setText("");
			ztQt.setText("0");
			ztPrix.setText("0.0");
			ztLocalisation.setText("R.E.C.B..");
			cbTypeC.setItems(FXCollections.observableList(facade.getListeTypesComposant()));
			// cbTypeC.setValue(cmp.getTypeCmp());
			cbTypeC.setDisable(false);
		}*/
	}

}
