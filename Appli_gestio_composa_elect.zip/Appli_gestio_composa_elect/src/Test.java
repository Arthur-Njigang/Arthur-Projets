import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import dao.CountryDAO;
import dao.DAOFactory;
import dao.DAOFactory.TypePersistance;
import dao.ICountryDAO;
import dao.exception.ComposantException;
import dao.exception.ComposantDoublonException;
import databases.connexion.ConnexionFromFile;
import databases.connexion.ConnexionSingleton;
import databases.connexion.IConnexionInfos;
import databases.connexion.InfoEmployeeEcole;
import databases.connexion.PersistanceException;
import databases.uri.Databases;
import model.Country;

public class Test {
	private static final Logger logger = LoggerFactory.getLogger(Test.class);

	public static void main(String[] args) {

		try {
			IConnexionInfos info =
					// new InfoEmployeeEcole();
					new ConnexionFromFile("ressources/connexion.properties", Databases.FIREBIRD);
			System.out.println(info.getProperties());
			ConnexionSingleton.setInfoConnexion(info);
			Connection connect = ConnexionSingleton.getConnexion();
			logger.info("YES la connexion est OK");
			/*** Test DAO ***/
			System.out.println("********************************");
			DAOFactory factory = DAOFactory.getDAOFactory(TypePersistance.FIREBIRD, connect);

			ICountryDAO dao = factory.getCountryDAO();
			List<Country> liste = dao.getCountryFromDevise("Euro");
			System.out.println(liste);
			int nbPays = dao.count();
			System.out.println("Nb Pays: " + nbPays);

			System.out.println(dao.getFromID("USA"));
			Country c = new Country("TestO", "POLO");
			try {
				c = dao.insert(c);
				logger.info("Création d'un pays: " + c);
				c = dao.insert(c);
				logger.info("Création d'un pays: " + c);
			} catch (Exception e) {
				if (e instanceof ComposantDoublonException exc)
					logger.error("Oups: " + exc.getMessage() + " " + exc.getNom());
				else
					logger.error("Oups: " + e.getMessage());
			}

			System.out.println("********************************");
			/*****************************/
			var pc = connect.prepareCall("call GET_EMP_PROJ(?,?)");
			pc.setInt(1, 24);
			pc.registerOutParameter(2, Types.VARCHAR);
			var rs = pc.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(1));
			}
			rs.close();
			pc.close();
			var st1 = connect.createStatement();
			var rs1 = st1.executeQuery("select * from country");
			while (rs1.next()) {
				System.out.println(rs1.getString(1) + " " + rs1.getString(2));
			}
			rs1.close();
			st1.close();

			var ps = connect.prepareStatement("select COUNTRY from country where CURRENCY = ?");
			ps.setString(1, "Euro");
			var rs2 = ps.executeQuery();
			while (rs2.next()) {
				System.out.println(rs2.getString("COUNTRY"));
			}
			rs2.close();
			ps.close();
			ConnexionSingleton.liberationConnexion();

		} catch (PersistanceException e) {
			System.err.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
