package model;

public enum TypeP {
	INT, FLOAT, STRING, BOOL
}
