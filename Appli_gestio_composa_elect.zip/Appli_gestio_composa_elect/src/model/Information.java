package model;

import java.util.Objects;

public class Information {
	private String valeur;
	private String unite;
	//private Propriete propriete;
	private IdInformation idInformation;

	/**
	 * @param valeur
	 * @param unite
	 * @param propriete
	 */
	public Information(IdInformation id, String valeur, String unite) {
		super();
		this.idInformation = id;
		this.valeur = valeur;
		this.unite = unite;
		//this.propriete = propriete;
	}
	

	public IdInformation getIdInformation() {
		return idInformation;
	}


	public void setIdInformation(IdInformation idInformation) {
		this.idInformation = idInformation;
	}

	public String getValeur() {
		return valeur;
	}

	public void setValeur(String valeur) {
		this.valeur = valeur;
	}

	public String getUnite() {
		return unite;
	}

	public void setUnite(String unite) {
		this.unite = unite;
	}

	@Override
	public int hashCode() {
		return Objects.hash(idInformation, unite, valeur);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Information other = (Information) obj;
		return Objects.equals(idInformation, other.idInformation) && Objects.equals(unite, other.unite)
				&& Objects.equals(valeur, other.valeur);
	}


	@Override
	public String toString() {
		return "Information [valeur=" + valeur + ", unite=" + unite + ", idInformation=" + idInformation + "]";
	}

}
