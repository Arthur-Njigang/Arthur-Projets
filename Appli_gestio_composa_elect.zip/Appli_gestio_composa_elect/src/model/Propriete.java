package model;

import java.util.List;
import java.util.Objects;

public class Propriete {
	private final String nom;
	private boolean obligatoire;
	private List<String> listeChoix;
	private List<String> listeUnite;
	private final TypeP typeP;
	private final String fkTypeCmp;

	/**
	 * @param nom
	 * @param obligatoire
	 * @param listeChoix
	 * @param listeUnite
	 * @param typeP
	 */
	public Propriete(String nom, boolean obligatoire, List<String> listeChoix, List<String> listeUnite, TypeP typeP, String fkTypePro) {
		this.nom = nom;
		this.obligatoire = obligatoire;
		this.listeChoix = listeChoix;
		this.listeUnite = listeUnite;
		this.typeP = typeP;
		this.fkTypeCmp = fkTypePro;
	}

	/**
	 * @param nom
	 * @param obligatoire
	 * @param listeChoix  un string avec les valeurs séparées par ";"
	 * @param listeUnite  un string avec les valeurs séparées par ";"
	 * @param typeP
	 */
	public Propriete(String nom, boolean obligatoire, String listeChoix, String listeUnite, TypeP typeP, String fkTypePro) {
		this(nom, obligatoire, List.of(listeChoix.split(";")), 
				List.of(listeUnite.split(";")), typeP, fkTypePro);
	}

	
	
	public String getFkTypeCmp() {
		return fkTypeCmp;
	}

	public String getNom() {
		return nom;
	}

	public boolean isObligatoire() {
		return obligatoire;
	}
	
	public void setObligatoire(boolean obligatoire) {
		this.obligatoire = obligatoire;
	}

	public String getListeUnite() {
		String llu = "";
		for(int i = 0; i < listeUnite.size(); i++) {
			if(i == listeUnite.size() - 1)llu += listeUnite.get(i);
			else llu += listeUnite.get(i) + ";";
		}
		
		return llu;
	}
	
	public String getListeChoix() {
		String llu = "";
		for(int i = 0; i < listeChoix.size(); i++) {
			if(i == listeChoix.size() - 1)llu += listeChoix.get(i);
			else llu += listeChoix.get(i) + ";";
		}
		
		return llu;
	}
	
	public void setListeUnite(String llu) {
		if(llu == null) return;
		listeUnite.clear();
		
		String []llus = llu.split(";");
		for(int i = 0; i < llus.length; i++) {
			listeUnite.add(llus[i]);
		}
	}
	
	public void setListeChoix(String llu) {
		if(llu == null) return;
		listeChoix.clear();
		
		String []llus = llu.split(";");
		for(int i = 0; i < llus.length; i++) {
			listeChoix.add(llus[i]);
		}
	}

	public TypeP getTypeP() {
		return typeP;
	}

	@Override
	public int hashCode() {
		return Objects.hash(listeChoix, listeUnite, nom, obligatoire, typeP);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Propriete other = (Propriete) obj;
		return Objects.equals(listeChoix, other.listeChoix) && Objects.equals(listeUnite, other.listeUnite)
				&& Objects.equals(nom, other.nom) && obligatoire == other.obligatoire && typeP == other.typeP;
	}

	@Override
	public String toString() {
		return "Propriete [nom=" + nom + ", obligatoire=" + obligatoire + ", typeP=" + typeP + "]";
	}

	public static void main(String[] args) {
		System.out.println(List.of("test1;test2;test3".split(";")));
	}
}
