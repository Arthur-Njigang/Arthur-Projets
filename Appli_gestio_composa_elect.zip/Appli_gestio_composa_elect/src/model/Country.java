package model;

import java.util.Objects;

public class Country {
	private String nom;
	private String devise;

	/**
	 * @param nom
	 * @param devise
	 */
	public Country(String nom, String devise) {
		super();
		this.nom = nom;
		this.devise = devise;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getDevise() {
		return devise;
	}

	public void setDevise(String devise) {
		this.devise = devise;
	}

	public String getNom() {
		return nom;
	}

	@Override
	public int hashCode() {
		return Objects.hash(devise, nom);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Country other = (Country) obj;
		return Objects.equals(devise, other.devise) && Objects.equals(nom, other.nom);
	}

	@Override
	public String toString() {
		return "Country [nom=" + nom + ", devise=" + devise + "]";
	}

}
