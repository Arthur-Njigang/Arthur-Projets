package model;

import java.util.Objects;

public class IdInformation {
	private Integer composant;
	private String propriete;
	
	public IdInformation(Integer composant, String propriete) {
		super();
		this.composant = composant;
		this.propriete = propriete;
	}

	@Override
	public String toString() {
		return "IdInformation [composant=" + composant + ", propriete=" + propriete + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(composant, propriete);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IdInformation other = (IdInformation) obj;
		return Objects.equals(composant, other.composant) && Objects.equals(propriete, other.propriete);
	}
	
	public Integer getComposant() {
		return composant;
	}
	public void setComposant(Integer composant) {
		this.composant = composant;
	}
	public String getPropriete() {
		return propriete;
	}
	public void setPropriete(String propriete) {
		this.propriete = propriete;
	}
	
	
}
