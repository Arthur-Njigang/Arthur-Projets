package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Composant {
	private Integer id;
	private String ref;
	private int qt;
	private double prix;
	private String localisation;
	private final String typeCmp;

	private List<Information> details = new ArrayList<>();

	/**
	 * @param id
	 * @param ref
	 * @param qt
	 * @param prix
	 * @param localisation
	 */
	public Composant(Integer id, String ref, int qt, double prix, String localisation, String typeCmp) {
		this.id = id;
		this.ref = ref;
		this.qt = qt;
		this.prix = prix;
		this.localisation = localisation;
		this.typeCmp = typeCmp;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, localisation, prix, qt, ref, typeCmp);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Composant other = (Composant) obj;
		/*return Objects.equals(id, other.id) && Objects.equals(localisation, other.localisation)
				&& Double.doubleToLongBits(prix) == Double.doubleToLongBits(other.prix) && qt == other.qt
				&& Objects.equals(ref, other.ref) && Objects.equals(typeCmp, other.typeCmp);*/
		
		return IsEquals(this, other);
	}
	
	public static boolean IsEquals(Composant c1, Composant c2) {
		if(c1 == null && c2 == null)return true;
		if(c1 == null || c2 == null)return false;
		
		if(((c1.getId() != null && c2.getId() != null && c1.getId().intValue() == c2.getId().intValue()) || 
				(c1.getId() == null && c2.getId() == null)) &&
			c1.getLocalisation().compareTo(c2.getLocalisation()) == 0 &&
			c1.getPrix() == c2.getPrix() &&
			c1.getQt() == c2.getQt() && 
			c1.getRef().compareTo(c2.getRef()) == 0 &&
			c1.getTypeCmp().compareTo(c2.getTypeCmp()) == 0) {
			return true;
		}
		
		return false;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public int getQt() {
		return qt;
	}

	public void setQt(int qt) {
		this.qt = qt;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}

	public String getLocalisation() {
		return localisation;
	}

	public void setLocalisation(String localisation) {
		this.localisation = localisation;
	}

	public String getTypeCmp() {
		return typeCmp;
	}

	public List<Information> getDetails() {
		return details;
	}

	public void setDetails(List<Information> details) {
		this.details = details;
	}

	@Override
	public String toString() {
		return "Composant [id=" + id + ", ref=" + ref + ", qt=" + qt + ", prix=" + prix + ", localisation="
				+ localisation + ", typeCmp=" + typeCmp + "]";
	}

	

}
