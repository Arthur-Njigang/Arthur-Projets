package model;

import java.util.List;
import java.util.Objects;

public class TypeComposant {
	private final String code;
	private final String nom;
	private List<Propriete> proprietes;

	/**
	 * @param code
	 * @param nom
	 * @param proprietes
	 */
	public TypeComposant(String code, String nom, List<Propriete> proprietes) {
		super();
		this.code = code;
		this.nom = nom;
		this.proprietes = proprietes;
	}

	public String getCode() {
		return code;
	}

	public String getNom() {
		return nom;
	}

	public List<Propriete> getProprietes() {
		return proprietes;
	}

	@Override
	public int hashCode() {
		return Objects.hash(code, nom, proprietes);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TypeComposant other = (TypeComposant) obj;
		return IsEquals(this, other);
	}
	
	public static boolean IsEquals(TypeComposant c1, TypeComposant c2) {
		if(c1 == null && c2 == null)return true;
		if(c1 == null || c2 == null)return false;
		
		if(c1.getCode().compareTo(c2.getCode()) == 0 &&
			c1.getNom().compareTo(c2.getNom()) == 0) {
			return true;
		}
		
		return false;
	}

	@Override
	public String toString() {
		return "TypeComposant [code=" + code + ", nom=" + nom + "]";
	}

}
