package service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Flow.Subscriber;

import dao.DAOFactory;
import dao.exception.ComposantException;
import javafx.scene.control.TextArea;
import dao.exception.ComposantDoublonException;
import model.Composant;
import model.Information;
import model.Propriete;
import service.ListMessages.Classe;
import service.ListMessages.Evenement;

public class Facade {
	// AccÃ¨s aux dao
	private DAOFactory factory;

	// Le publisher
	private PublisherEvent publisher;

	// Pour simulation
	List<Composant> liste = new ArrayList<>();

	private Integer maxi;

	private List<String> typeC;
	
	public TextArea InformationArea;
	public TextArea ComposantArea;

	/**
	 * @param factory
	 */
	public Facade(DAOFactory factory) {
		// La fabrique pour accÃ©der aux DAOs
		this.factory = factory;

		// Le Publisher pour publier les Ã©vÃ¨nements
		publisher = new PublisherEvent();

		typeC = List.of("RES", "COND", "IC");

		Composant c;
		for (int i = 1; i < 10; i++) {
			String typex = typeC.get(((int) (Math.random() * 10)) % 3);
			int rnd = ((int) (Math.random() * 10)) % 100;
			c = new Composant(i, typex.charAt(0) + "" + i, rnd, rnd * 0.2, "B01C01", typex);
			liste.add(c);
		}
		// FIN A SUPPRIMER
	}

	/**
	 * Obtenir un composant via son ID
	 * 
	 * @param id
	 * @return un optional de composant
	 */
	public Optional<Composant> getComposant(Integer id) {
		return liste.stream().filter(e -> e.getId() == id).findFirst();

	}

	/**
	 * Obtenir un composant via sa rÃ©fÃ©rence
	 * 
	 * @param ref
	 * @return un optional de composant
	 */
	public Optional<Composant> getComposant(String ref) {
		return this.liste.stream().filter(e -> e.getRef() == ref).findFirst();
	}

	/**
	 * CrÃ©e un nouveau composant
	 * 
	 * @param cmp le composant avec un ID Ã  null
	 * @return le composant avec un ID gÃ©nÃ©rÃ©
	 */
	public Composant createComposant(Composant cmp) throws ComposantException{
		assert cmp.getId() == null : "L'identifiant doit Ãªtre vide";
		//vÃ©rifie s'il n'existe pas de doublon sur la rÃ©fÃ©rence du composant
		if (liste.stream().anyMatch((c)->c.getRef().equals(cmp.getRef())))
			throw new ComposantDoublonException("Doublon", "REF");
		//Calcul un nouvel identifiant
		maxi = 1;
		liste.forEach(e -> maxi = Math.max(maxi, e.getId()));
		cmp.setId(maxi + 1);
		liste.add(cmp);
		// publie l'Ã©vÃ¨nement
		Map<Classe, Evenement> messages = new HashMap<>();
		messages.put(Classe.COMPOSANT, new Evenement(TypeOperation.INSERT, cmp));
		publisher.submit(new ListMessages(messages));
		
		ComposantArea.appendText("INSERT SUR "+cmp.getRef()+"\n");

		return cmp;
	}

	/**
	 * Mis Ã  jour d'un composant
	 * 
	 * @param cmp le composant
	 */
	public void updateComposant(Composant cmp) throws ComposantException{
		// recherche le composant
		Composant c = liste.stream().filter(e -> e.getId() == cmp.getId()).findFirst().orElseThrow();
		liste.remove(c);
		liste.add(c);

		// publie l'Ã©vÃ¨nement
		Map<Classe, Evenement> messages = new HashMap<>();
		messages.put(Classe.COMPOSANT, new Evenement(TypeOperation.UPDATE, c));
		publisher.submit(new ListMessages(messages));
	}

	/**
	 * Retourne la liste des composants sans charger ses propriÃ©tÃ©s
	 * 
	 * @return liste des composants
	 */
	public List<Composant> getListe() {
		// List<Composant> copie=new ArrayList<Composant>(liste);
		return List.copyOf(liste);
	}

	/**
	 * Retourne la liste de toutes les rÃ©fÃ©rences des composant
	 * 
	 * @return liste de rÃ©fÃ©rences
	 */
	public List<String> getListeRefComposant() {
		List<String> codes = new ArrayList<>();
		liste.forEach(c -> codes.add(c.getRef()));
		return codes;
	}

	/**
	 * Supprime un composant
	 * 
	 * @param id
	 */
	public void deleteComposant(Integer id) throws ComposantException {
		// recherche le composant
		Composant c = liste.stream().filter(e -> e.getId() == id).findFirst()
				.orElseThrow(() -> new ComposantException("Suppression impossible"));
		
		liste.remove(c);
		// publie l'Ã©vÃ¨nement
		Map<Classe, Evenement> messages = new HashMap<>();
		messages.put(Classe.COMPOSANT, new Evenement(TypeOperation.DELETE, c));
		publisher.submit(new ListMessages(messages));
	}
	
	
	public List<String> getListeTypesComposant(){
		return new ArrayList<String>(typeC);
	}

	/**
	 * Permet de s'abonner aux Ã©vÃ¨nements sur le modÃ¨le
	 */
	public void addObserver(Subscriber<ListMessages> obs) {
		publisher.addObserver(obs);
	}
	
	public DAOFactory getDAOFactory() {
		return this.factory;
	}
	
	/**
	 * Mis Ã  jour d'une propiete
	 * 
	 * @param cmp le composant
	 * @throws Exception 
	 */
	public void updatePropriete(Propriete propriete) throws Exception{
		Optional<Propriete> prop = factory.getProprieteDAO().getFromID(propriete.getNom());
		if(prop.isPresent()) {
			List<Composant> com = factory.getComposantDAO().getFromType(propriete.getFkTypeCmp());
			if(com != null && com.size() > 0) {
				for(int i = 0; i < com.size(); i++) {
					List<Information> inf = factory.getInformationDAO().getListeFromComposant(com.get(i));
					if(inf != null && inf.size() > 0) {
						for(int j = 0; j < inf.size(); j++) {
							if(inf.get(j).getIdInformation().getPropriete().compareTo(propriete.getNom()) == 0) {
								InformationArea.appendText("UPDATE sur IdInformation [Composant="+com.get(i).getId()
										+", propriete="+propriete.getNom()+"]\n");
							}
						}
					}
				}
			}
		}
		boolean update_success = factory.getProprieteDAO().update(propriete);
		// recherche le composant
		//boolean update_success = factory.getProprieteDAO().update(propriete);
	}

}
