package databases.uri;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.AfterClass;

public class TestDatabases {
	@Test
	public void testFirebirdURL() {
		assertFalse(Databases.FIREBIRD.hasMemoryMode());
		assertTrue(Databases.FIREBIRD.hasEmbeddedMode());
		assertTrue(Databases.FIREBIRD.hasServeurMode());
		assertEquals(Databases.FIREBIRD.buildServeurURL("employee", "192.168.0.5"),
				"jdbc:firebirdsql:192.168.0.5/3050:employee");
		assertEquals(Databases.FIREBIRD.buildServeurURL("employee", "192.168.0.5", 1234),
				"jdbc:firebirdsql:192.168.0.5/1234:employee");
	}

	@Test
	public void testH2URL() {
		assertTrue(Databases.H2.hasMemoryMode());
		assertTrue(Databases.H2.hasEmbeddedMode());
		assertTrue(Databases.H2.hasServeurMode());
		assertEquals(Databases.H2.buildServeurURL("employee", "192.168.0.5"),
				"jdbc:h2:tcp://192.168.0.5:8082/employee");
		assertEquals(Databases.H2.buildServeurURL("employee", "192.168.0.5", 1234),
				"jdbc:h2:tcp://192.168.0.5:1234/employee");
	}

	@BeforeClass
	public void beforeClass() {
		System.out.println("BEFORE");
	}

	@AfterClass
	public void afterClass() {
		System.out.println("AFTER");
	}

}
