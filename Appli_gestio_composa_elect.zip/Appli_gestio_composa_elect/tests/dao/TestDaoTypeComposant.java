package dao;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Optional;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import dao.DAOFactory.TypePersistance;
import databases.connexion.ConnexionFromFile;
import databases.connexion.ConnexionSingleton;
import databases.connexion.PersistanceException;
import databases.uri.Databases;
import model.Composant;
import model.TypeComposant;
import utils.DatabaseUtil;

public class TestDaoTypeComposant {
	private DAOFactory factory;
	private ITypeComposantDAO dao;
	
	private static final TypeComposant R1 = new TypeComposant("RES", "RESISTANCE", null);
	private static final TypeComposant C47 = new TypeComposant("COND", "CONDENSATEUR", null);
	
	@Test
	public void testGetDaoTypeComposant() {
		Optional<TypeComposant> c = dao.getFromID(R1.getCode());
		// Vérifie si l'objet existe
		assertTrue(c.isPresent());
		assertEquals(c.get(), R1);
	}
	
	@Test
	public void testGetDaoGetList() {
		List<TypeComposant> l = dao.getListe(null);
		assertEquals(l.size(), 4);

		// Vérifie l'existance dans la liste
		assertTrue(l.contains(R1));
		assertTrue(l.contains(C47));
	}
	
	@Test
	public void testGetDaoGetListSorted() {
		List<TypeComposant> l = dao.getListe(null);
		assertEquals(l.size(), 4);
		
		List<TypeComposant> l2 = dao.getListeRef();
		assertEquals(l2.size(), 4);
		
		boolean identique = true;
		for(int i = 0;i < 4; i++) {
			if(!TypeComposant.IsEquals(l.get(i), l2.get(i))) {
				identique = false;
			}
		}
		
		assertEquals(identique, false);
	}
	
	
	@BeforeClass
	public void beforeClass() throws PersistanceException, FileNotFoundException {
		ConnexionSingleton.setInfoConnexion(
				new ConnexionFromFile("./ressources/connexionComposant_Test.properties", Databases.FIREBIRD));
		// Réinitialise la base de données dans son état initial
		DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(),
		"./ressources/scriptInitDBTest.sql");
		factory = DAOFactory.getDAOFactory(TypePersistance.FIREBIRD, ConnexionSingleton.getConnexion());
		dao = factory.getTypeComposantDAO();
	}

	/**
	 * Exécuté une fois et ceci après tous les tests de cette classe
	 * 
	 * @throws PersistanceException
	 * @throws FileNotFoundException
	 */
	@AfterClass
	public void afterClass() throws FileNotFoundException, PersistanceException {
		// Réinitialise la base de données dans son état initial
		DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(), "./ressources/scriptInitDBTest.sql");
		ConnexionSingleton.liberationConnexion();
	}
}
