package dao;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Optional;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import dao.DAOFactory.TypePersistance;
import dao.exception.ComposantDoublonException;
import dao.exception.ComposantException;
import databases.connexion.ConnexionFromFile;
import databases.connexion.ConnexionSingleton;
import databases.connexion.PersistanceException;
import databases.uri.Databases;
import model.Composant;
import utils.DatabaseUtil;

public class TestDaoComposant {
	private DAOFactory factory;

	private static final Composant R1 = new Composant(1, "R1", 100, 0.2, "B01C01", "RES");
	private static final Composant C47 = new Composant(4, "C47", 50, 1.2, "B10C02", "COND");

	private IComposantDAO dao;

	/**
	 * Test un getFromId
	 */
	@Test
	public void testGetDaoComposant() {
		Optional<Composant> c = dao.getFromID(R1.getId());
		// Vérifie si l'objet existe
		assertTrue(c.isPresent());
		assertEquals(c.get(), R1);
	}

	/**
	 * Teste un getListe
	 */
	@Test
	public void testGetListeComposants() {
		List<Composant> l = dao.getListe(null);
		assertEquals(l.size(), 4);

		// Vérifie l'existance dans la liste
		assertTrue(l.contains(R1));
		assertTrue(l.contains(C47));
	}

	/**
	 * Test l'ajout et la suppression
	 * 
	 * @throws Exception
	 */
	@Test
	public void testGetInsertDeleteDaoPersonnel() throws Exception {

		// Un nouveau composant
		Composant ic1 = new Composant(null, "CD4001", 10, 21, "B20C01", "IC");
		Integer id = dao.insert(ic1).getId();
		// vérifie si le code renvoyé est le bon
		assertEquals(id, (Integer) 5);
		// vérifie que l'on récupére bien le même composant
		Optional<Composant> c = dao.getFromID(id);
		assertTrue(c.isPresent());
		ic1.setId(5);
		assertEquals(c.get(), ic1);
		// Test Supression
		assertTrue(dao.delete(ic1));
		// Verifie qu'il n'existe plus
		c = dao.getFromID(id);
		assertFalse(c.isPresent());
	}

	@Test
	public void testInsertUpdateDelete() throws Exception {
		// Un nouveau composant

		Composant cNew = new Composant(null, "CD4001", 10, 21, "B20C01", "IC");
		Composant cModif = new Composant(null, "CD4001", 20, 2, "B00C00", "IC");

		cNew = dao.insert(cNew);
		Optional<Composant> c = dao.getFromID(cNew.getId());
		assertTrue(c.isPresent());
		assertEquals(c.get(), cNew);
		// Modification
		cModif.setId(cNew.getId()); // ajuste l'id
		boolean res = dao.update(cModif);
		// test ok
		assertTrue(res);
		// récupère l'objet pour voir si changement ok
		Optional<Composant> cRetour = dao.getFromID(cModif.getId());
		assertTrue(cRetour.isPresent());
		assertEquals(cModif, cRetour.get());
		// Annule l'enregistrement pour revenir au même point de départ
		assertTrue(dao.delete(cRetour.get()));

	}

	// Insertion avec Exception attendue
	@Test(expectedExceptions = ComposantDoublonException.class)
	public void testBadPKInsert() throws Exception {
		dao.insert(R1);
	}

	// Insertion avec Exception attendue
	@Test(expectedExceptions = ComposantDoublonException.class)
	public void testBadRefInsert() throws Exception {
		Composant c = new Composant(null, "R1", 10, 0.1, "B01C01", "COND");

		dao.insert(c).getId();
	}

	/**
	 * Exécuté une fois et ceci avant tous les tests de cette classe
	 * 
	 * @throws PersistanceException
	 * @throws FileNotFoundException
	 */
	@BeforeClass
	public void beforeClass() throws PersistanceException, FileNotFoundException {
		ConnexionSingleton.setInfoConnexion(
				new ConnexionFromFile("./ressources/connexionComposant_Test.properties", Databases.FIREBIRD));
		// Réinitialise la base de données dans son état initial
		DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(),
		"./ressources/scriptInitDBTest.sql");
		factory = DAOFactory.getDAOFactory(TypePersistance.FIREBIRD, ConnexionSingleton.getConnexion());
		dao = factory.getComposantDAO();
	}

	/**
	 * Exécuté une fois et ceci après tous les tests de cette classe
	 * 
	 * @throws PersistanceException
	 * @throws FileNotFoundException
	 */
	@AfterClass
	public void afterClass() throws FileNotFoundException, PersistanceException {
		// Réinitialise la base de données dans son état initial
		DatabaseUtil.executeScriptSQL(ConnexionSingleton.getConnexion(), "./ressources/scriptInitDBTest.sql");
		ConnexionSingleton.liberationConnexion();
	}

}
