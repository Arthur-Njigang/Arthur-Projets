-- Création de la base de données
CREATE DATABASE IF NOT EXISTS site_pc;
USE site_pc;

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(100) NOT NULL,
    role ENUM('admin', 'gestionnaire', 'client') DEFAULT 'client',
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Créez l'utilisateur admin
CREATE USER 'admin'@'localhost' IDENTIFIED BY 'password';

-- Accordez les privilèges à l'utilisateur admin
GRANT ALL PRIVILEGES ON site_pc.* TO 'admin'@'%';
FLUSH PRIVILEGES;

INSERT INTO users (username, email, password, role, createdAt, updatedAt) VALUES ('admin', 'admin@gmail.com', SHA2('admin', 256), 'admin', NOW(), NOW());
INSERT INTO users (username, email, password, role, createdAt, updatedAt) VALUES ('gestionnaire', 'gest@gmail.com', SHA2('gest', 256), 'gestionnaire', NOW(), NOW());
INSERT INTO users (username, email, password, role, createdAt, updatedAt) VALUES ('user1', 'user@gmail.com', SHA2('user', 256), 'client', NOW(), NOW());


INSERT INTO users (username, email, password, role, createdAt, updatedAt) VALUES ('admin', 'admin@example.com', SHA2('admin', 256), 'admin', NOW(), NOW());

-- Table des informations des utilisateurs
CREATE TABLE IF NOT EXISTS infos_users (
    id INT NOT NULL AUTO_INCREMENT,
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telephone VARCHAR(10) NOT NULL,
    ville VARCHAR(50) NOT NULL,
    rue VARCHAR(50) NOT NULL,
    codePostal INT NOT NULL,
    numeroCompte VARCHAR(20) DEFAULT NULL,
    numeroMaison VARCHAR(10) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    PRIMARY KEY (id),
    FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des produits
CREATE TABLE IF NOT EXISTS products (
    id INT NOT NULL AUTO_INCREMENT,
    nom VARCHAR(50) NOT NULL,
    prix DOUBLE NOT NULL,
    marque ENUM('mac-os', 'dell', 'hp', 'lenovo', 'asus', 'acer') NOT NULL,
    specifications VARCHAR(1500) NOT NULL,
    quantiteStock INT NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Insertion  produits dans la table products
INSERT INTO products (nom, prix, marque, specifications, quantiteStock, createdAt, updatedAt)
VALUES
    ('MacBook Pro', 2399.99, 'mac-os', '16-inch, 16GB RAM, 512GB SSD, Intel i7', 50, NOW(), NOW()),
    ('Dell XPS 13', 999.99, 'dell', '13-inch, 8GB RAM, 256GB SSD, Intel i5', 70, NOW(), NOW()),
    ('HP Spectre x360', 1199.99, 'hp', '15-inch, 16GB RAM, 512GB SSD, Intel i7', 40, NOW(), NOW()),
    ('Lenovo ThinkPad X1 Carbon', 1299.99, 'lenovo', '14-inch, 16GB RAM, 1TB SSD, Intel i7', 30, NOW(), NOW()),
    ('Asus ROG Zephyrus', 1499.99, 'asus', '15-inch, 32GB RAM, 1TB SSD, Intel i9', 20, NOW(), NOW()),
    ('Acer Predator Helios', 1099.99, 'acer', '15-inch, 16GB RAM, 512GB SSD, Intel i7', 25, NOW(), NOW()),
    ('MacBook Air', 999.99, 'mac-os', '13-inch, 8GB RAM, 256GB SSD, M1 Chip', 60, NOW(), NOW()),
    ('Dell Inspiron 15', 799.99, 'dell', '15-inch, 8GB RAM, 256GB SSD, Intel i5', 80, NOW(), NOW()),
    ('HP Pavilion', 699.99, 'hp', '15-inch, 8GB RAM, 256GB SSD, Intel i5', 90, NOW(), NOW()),
    ('Lenovo Yoga 7i', 849.99, 'lenovo', '14-inch, 12GB RAM, 512GB SSD, Intel i5', 45, NOW(), NOW()),
    ('Asus VivoBook', 599.99, 'asus', '15-inch, 8GB RAM, 256GB SSD, Intel i3', 100, NOW(), NOW()),
    ('Acer Aspire 5', 549.99, 'acer', '15-inch, 8GB RAM, 256GB SSD, Intel i3', 110, NOW(), NOW());


-- Table des commandes
CREATE TABLE IF NOT EXISTS commandes (
    id INT NOT NULL AUTO_INCREMENT,
    total_commande DOUBLE NOT NULL,
    statut_commande ENUM('En cours', 'En attente', 'Payee', 'Annulee', 'Livree') NOT NULL,
    date_livraison DATETIME DEFAULT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    PRIMARY KEY (id),
    FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des lignes de commande
CREATE TABLE IF NOT EXISTS ligne_commandes (
    id INT NOT NULL AUTO_INCREMENT,
    quantite INT NOT NULL,
    prix DOUBLE NOT NULL,
    id_product INT NOT NULL,
    id_commande INT NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_product) REFERENCES products(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_commande) REFERENCES commandes(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des retours
CREATE TABLE IF NOT EXISTS retours (
    id INT NOT NULL AUTO_INCREMENT,
    quantite INT NOT NULL,
    motifRetour VARCHAR(255) NOT NULL,
    statutRetour ENUM('En cours', 'Accepté', 'Refusé') NOT NULL,
    a_rembourser DOUBLE NOT NULL,
    numeroSerie VARCHAR(9) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    id_commande INT,
    id_product INT,
    PRIMARY KEY (id),
    FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_commande) REFERENCES commandes(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_product) REFERENCES products(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des commentaires
CREATE TABLE IF NOT EXISTS commentaires (
    id INT NOT NULL AUTO_INCREMENT,
    commentaire VARCHAR(255) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    id_product INT,
    PRIMARY KEY (id),
    FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (id_product) REFERENCES products(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des images
CREATE TABLE IF NOT EXISTS images (
    id INT NOT NULL AUTO_INCREMENT,
    image_url VARCHAR(255) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_product INT,
    PRIMARY KEY (id),
    FOREIGN KEY (id_product) REFERENCES products(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des adresses de livraison
CREATE TABLE IF NOT EXISTS shipping_addresses (
    id INT NOT NULL AUTO_INCREMENT,
    ville VARCHAR(50) NOT NULL,
    rue VARCHAR(50) NOT NULL,
    numeroMaison VARCHAR(10) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    PRIMARY KEY (id),
    FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des factures
CREATE TABLE IF NOT EXISTS factures (
    id INT NOT NULL AUTO_INCREMENT,
    total_facture DOUBLE NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    id_paiement INT,
    PRIMARY KEY (id),
    FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des paiements
CREATE TABLE IF NOT EXISTS paiements (
    id INT NOT NULL AUTO_INCREMENT,
    id_commande INT NOT NULL,
    method_paiement VARCHAR(255) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_commande) REFERENCES commandes(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table des messages
CREATE TABLE IF NOT EXISTS messages (
    id INT NOT NULL AUTO_INCREMENT,
    objet VARCHAR(100) NOT NULL,
    contenu VARCHAR(1000) NOT NULL,
    is_in_coming TINYINT(1) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    PRIMARY KEY (id),
    FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Fin du script
COMMIT;
