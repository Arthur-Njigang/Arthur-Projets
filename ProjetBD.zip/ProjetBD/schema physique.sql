-- Utilisateurs
CREATE TABLE Utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    connexion VARCHAR(255) NOT NULL,
    password VARCHAR(100) NOT NULL,
    role ENUM('admin', 'user', 'gestionnaire') NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Commandes
CREATE TABLE Commandes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    total_commande DOUBLE NOT NULL,
    statut_commande ENUM('En cours', 'En attente', 'Payé', 'Annulé', 'Livré') NOT NULL,
    date_livraison DATETIME,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    FOREIGN KEY (id_user) REFERENCES Utilisateurs(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Produits
CREATE TABLE Produits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    prix DOUBLE NOT NULL,
    marque ENUM('mac-os', 'dell', 'hp', 'lenovo', 'asus', 'acer') NOT NULL,
    specifications VARCHAR(1500) NOT NULL,
    quantiteStock INT NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Paiements
CREATE TABLE Paiements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_commande INT NOT NULL,
    method_paiement VARCHAR(255) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    FOREIGN KEY (id_commande) REFERENCES Commandes(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Ligne Commandes
CREATE TABLE Ligne_Commandes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quantite INT NOT NULL,
    prix INT NOT NULL,
    id_product INT NOT NULL,
    id_commande INT,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    FOREIGN KEY (id_product) REFERENCES Produits(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_commande) REFERENCES Commandes(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Commentaires
CREATE TABLE Commentaires (
    id INT AUTO_INCREMENT PRIMARY KEY,
    commentaire VARCHAR(255) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    id_product INT,
    FOREIGN KEY (id_user) REFERENCES Utilisateurs(id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (id_product) REFERENCES Produits(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Images
CREATE TABLE Images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image_url VARCHAR(255) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_product INT,
    FOREIGN KEY (id_product) REFERENCES Produits(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Infos_Users
CREATE TABLE Infos_Users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telephone VARCHAR(10) NOT NULL,
    ville VARCHAR(50) NOT NULL,
    rue VARCHAR(50) NOT NULL,
    codePostal INT NOT NULL,
    numeroCompte VARCHAR(20),
    numeroMaison VARCHAR(10) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    FOREIGN KEY (id_user) REFERENCES Utilisateurs(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Retours
CREATE TABLE Retours (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quantite INT NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_commande INT,
    id_user INT,
    id_product INT,
    FOREIGN KEY (id_commande) REFERENCES Commandes(id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (id_user) REFERENCES Utilisateurs(id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (id_product) REFERENCES Produits(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Ligne_Retours
CREATE TABLE Ligne_Retours (
    id INT AUTO_INCREMENT PRIMARY KEY,
    motifRetour VARCHAR(255) NOT NULL,
    statutRetour ENUM('En cours', 'Accepté', 'Refusé') NOT NULL,
    a_rembourser DOUBLE NOT NULL,
    numeroSerie VARCHAR(9) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    id_retour INT,
    FOREIGN KEY (id_user) REFERENCES Utilisateurs(id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (id_retour) REFERENCES Retours(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Adresse_Livraison
CREATE TABLE Adresse_Livraison (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ville VARCHAR(50) NOT NULL,
    rue VARCHAR(50) NOT NULL,
    codePostal INT NOT NULL,
    numeroMaison VARCHAR(10) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    FOREIGN KEY (id_user) REFERENCES Utilisateurs(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Messages
CREATE TABLE Messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    objet VARCHAR(100) NOT NULL,
    contenu VARCHAR(1000) NOT NULL,
    is_in_coming TINYINT(1) NOT NULL,
    createdAt DATETIME NOT NULL,
    updatedAt DATETIME NOT NULL,
    id_user INT,
    FOREIGN KEY (id_user) REFERENCES Utilisateurs(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
