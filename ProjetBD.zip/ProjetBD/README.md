## dans le dossier out 
"schema logique"
"schema conceptuel"


## Pour  lancer le projet 

"docker-compose down -v"

"docker-compose up --build"

## acceder a la bd en ligne de commande 
"docker ps" 
"docker exec -it <id container> bash"
"mysql -uadmin -ppassword "
"USE site_pc"

## voir les differentes tables 

"SHOW TABLES"

## compte admin et gestionnaire par defaut deja present dans la bd  

"username: admin"
"mdp:  admin"

"username: gestionnaire"
"mdp:  gest"

## un user par defaut dans la bd 

"username: user1"
"mdp:  user"