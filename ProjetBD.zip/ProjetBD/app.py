import hashlib
import os
from datetime import datetime

import mysql.connector
from flask import (Flask, flash, redirect, render_template, request, session,
                   url_for)

app = Flask(__name__)
app.secret_key = 'votre_clé_secrète'

# Configuration de la connexion à la base de données
config = {
    'user': 'admin',
    'password': 'password',
    'host': 'mysql',  
    'port': '3306',
    'database': 'site_pc',
    'raise_on_warnings': True
}

def get_db_connection():
    return mysql.connector.connect(**config)

def format_datetime(value, format='%Y-%m-%d %H:%M:%S'):
    if value is None:
        return ""
    return value.strftime(format)

# Enregistrement du filtre dans Jinja2
app.jinja_env.filters['datetime'] = format_datetime

@app.route('/signup', methods=['POST'])
def signup():
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()

    # Récupération des données du formulaire
    username = request.form['username']
    email = request.form['email']
    password = request.form['password']

    # Hashage du mot de passe
    hashed_password = hashlib.sha256(password.encode()).hexdigest()

    # Date actuelle pour les champs createdAt et updatedAt
    now = datetime.now()

    # Insertion de l'utilisateur dans la base de données
    try:
        cursor.execute(
            "INSERT INTO users (username, email, password, role, createdAt, updatedAt) VALUES (%s, %s, %s, %s, %s, %s)",
            (username, email, hashed_password, 'client', now, now)
        )
        conn.commit()
        flash('Inscription réussie! Vous pouvez maintenant vous connecter.', 'success')
    except mysql.connector.Error as err:
        print("Something went wrong: {}".format(err))
        conn.rollback()
        flash('Échec de l\'inscription. Veuillez réessayer.', 'danger')

    cursor.close()
    conn.close()

    return redirect(url_for('connexion'))

@app.route('/login', methods=['POST'])
def login():
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)

    username = request.form['username']
    password = request.form['password']
    hashed_password = hashlib.sha256(password.encode()).hexdigest()

    cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, hashed_password))
    user = cursor.fetchone()

    cursor.close()
    conn.close()

    if user:
        session['username'] = username
        session['user_id'] = user['id']  # Stockez l'ID de l'utilisateur dans la session
        session['role'] = user['role']
        flash('Connexion réussie.', 'success')
        return redirect(url_for('home'))
    else:
        flash('Identifiants invalides. Veuillez réessayer.', 'danger')
        return redirect(url_for('connexion'))


@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('role', None)
    flash('Vous êtes déconnecté.', 'success')
    return redirect(url_for('home'))

@app.route('/')
def home():
    role = session.get('role')
    return render_template('home.html', role=role)

@app.route('/connexion')
def connexion():
    return render_template('connexion.html')



@app.route('/admin_dashboard')
def admin_dashboard():
    if 'role' in session and session['role'] == 'admin':
        return render_template('admin_dashboard.html')
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))

@app.route('/manager_dashboard')
def manager_dashboard():
    if 'role' in session and session['role'] == 'gestionnaire':
        return render_template('manager_dashboard.html')
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))

@app.route('/admin/products', methods=['GET', 'POST'])
def manage_products():
    if 'role' in session and session['role'] in ['admin', 'gestionnaire']:
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor(dictionary=True)

        if request.method == 'POST':
            # Ajouter un nouveau produit
            if 'add_product' in request.form:
                nom = request.form['nom']
                prix = request.form['prix']
                marque = request.form['marque']
                specifications = request.form['specifications']
                quantiteStock = request.form['quantiteStock']
                now = datetime.now()

                cursor.execute(
                    "INSERT INTO products (nom, prix, marque, specifications, quantiteStock, createdAt, updatedAt) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                    (nom, prix, marque, specifications, quantiteStock, now, now)
                )
                conn.commit()
                flash('Produit ajouté avec succès.', 'success')

            # Modifier un produit existant
            if 'update_product' in request.form:
                product_id = request.form['product_id']
                nom = request.form['nom']
                prix = request.form['prix']
                marque = request.form['marque']
                specifications = request.form['specifications']
                quantiteStock = request.form['quantiteStock']
                now = datetime.now()

                cursor.execute(
                    "UPDATE products SET nom = %s, prix = %s, marque = %s, specifications = %s, quantiteStock = %s, updatedAt = %s WHERE id = %s",
                    (nom, prix, marque, specifications, quantiteStock, now, product_id)
                )
                conn.commit()
                flash('Produit mis à jour avec succès.', 'success')

            # Supprimer un produit
            if 'delete_product' in request.form:
                product_id = request.form['product_id']
                cursor.execute("DELETE FROM products WHERE id = %s", (product_id,))
                conn.commit()
                flash('Produit supprimé avec succès.', 'success')

        cursor.execute("SELECT * FROM products")
        products = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('admin_dashboard.html', section='products', products=products)
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))

@app.route('/admin/users', methods=['GET', 'POST'])
def manage_users():
    if 'role' in session and session['role'] == 'admin':
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor(dictionary=True)

        if request.method == 'POST':
            # Ajouter un nouvel utilisateur
            if 'add_user' in request.form:
                username = request.form['username']
                email = request.form['email']
                password = request.form['password']
                role = request.form['role']
                hashed_password = hashlib.sha256(password.encode()).hexdigest()
                now = datetime.now()

                cursor.execute(
                    "INSERT INTO users (username, email, password, role, createdAt, updatedAt) VALUES (%s, %s, %s, %s, %s, %s)",
                    (username, email, hashed_password, role, now, now)
                )
                conn.commit()
                flash('Utilisateur ajouté avec succès.', 'success')

            # Modifier un utilisateur existant
            if 'update_user' in request.form:
                user_id = request.form['user_id']
                username = request.form['username']
                email = request.form['email']
                role = request.form['role']
                password = request.form['password']
                now = datetime.now()

                # Mise à jour avec ou sans mot de passe
                if password:
                    hashed_password = hashlib.sha256(password.encode()).hexdigest()
                    cursor.execute(
                        "UPDATE users SET username = %s, email = %s, role = %s, password = %s, updatedAt = %s WHERE id = %s",
                        (username, email, role, hashed_password, now, user_id)
                    )
                else:
                    cursor.execute(
                        "UPDATE users SET username = %s, email = %s, role = %s, updatedAt = %s WHERE id = %s",
                        (username, email, role, now, user_id)
                    )

                conn.commit()
                flash('Utilisateur mis à jour avec succès.', 'success')

            # Supprimer un utilisateur
            if 'delete_user' in request.form:
                user_id = request.form['user_id']
                cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
                conn.commit()
                flash('Utilisateur supprimé avec succès.', 'success')

        cursor.execute("SELECT * FROM users")
        users = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('admin_dashboard.html', section='users', users=users)
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'username' not in session:
        flash('Vous devez être connecté pour accéder à cette page.', 'danger')
        return redirect(url_for('connexion'))
    
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)
    
    if request.method == 'POST':
        if 'update_profile' in request.form:
            username = request.form['username']
            email = request.form['email']
            cursor.execute(
                "UPDATE users SET username = %s, email = %s WHERE username = %s",
                (username, email, session['username'])
            )
            conn.commit()
            session['username'] = username  # Mise à jour de la session avec le nouveau nom d'utilisateur
            flash('Profil mis à jour avec succès.', 'success')
        
        elif 'update_password' in request.form:
            current_password = request.form['current_password']
            new_password = request.form['new_password']
            hashed_current_password = hashlib.sha256(current_password.encode()).hexdigest()
            hashed_new_password = hashlib.sha256(new_password.encode()).hexdigest()

            cursor.execute(
                "SELECT * FROM users WHERE username = %s AND password = %s",
                (session['username'], hashed_current_password)
            )
            user = cursor.fetchone()
            
            if user:
                cursor.execute(
                    "UPDATE users SET password = %s WHERE username = %s",
                    (hashed_new_password, session['username'])
                )
                conn.commit()
                flash('Mot de passe mis à jour avec succès.', 'success')
            else:
                flash('Mot de passe actuel incorrect.', 'danger')
        
        elif 'delete_account' in request.form:
            if 'username' not in session:
                flash('Vous devez être connecté pour supprimer votre compte.', 'danger')
                return redirect(url_for('connexion'))

            username = session['username']
            conn = mysql.connector.connect(**config)
            cursor = conn.cursor()

            try:
                # Anonymiser les données historiques
                cursor.execute("UPDATE commandes SET id_user = NULL WHERE id_user = (SELECT id FROM users WHERE username = %s)", (username,))
                cursor.execute("UPDATE factures SET id_user = NULL WHERE id_user = (SELECT id FROM users WHERE username = %s)", (username,))
                cursor.execute("UPDATE shipping_addresses SET id_user = NULL WHERE id_user = (SELECT id FROM users WHERE username = %s)", (username,))

                # Supprimer l'utilisateur
                cursor.execute("DELETE FROM users WHERE username = %s", (username,))

                conn.commit()
                flash('Votre compte a été supprimé avec succès.', 'success')
            except mysql.connector.Error as err:
                print(f"Something went wrong: {err}")
                conn.rollback()
                flash('Une erreur est survenue lors de la suppression de votre compte. Veuillez réessayer.', 'danger')
            finally:
                cursor.close()
                conn.close()

            # Déconnecter l'utilisateur
            session.pop('username', None)
            session.pop('role', None)

            return redirect(url_for('home'))
    
    cursor.execute("SELECT username, email, role FROM users WHERE username = %s", (session['username'],))
    user = cursor.fetchone()
    
    cursor.close()
    conn.close()
    
    return render_template('profile.html', user=user)

@app.route('/admin/clients', methods=['GET', 'POST'])
def manage_clients():
    if 'role' in session and session['role'] in ['admin', 'gestionnaire']:
        if request.method == 'POST':
            # Handle client management form submission
            pass
        return render_template('admin_dashboard.html', section='clients')
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))

@app.route('/admin/orders', methods=['GET', 'POST'])
def manage_orders():
    if 'role' in session and session['role'] in ['admin', 'gestionnaire']:
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor(dictionary=True)

        if request.method == 'POST':
            # Modifier une commande existante
            if 'update_order' in request.form:
                order_id = request.form['order_id']
                statut_commande = request.form['statut_commande']
                date_livraison = request.form['date_livraison']
                now = datetime.now()

                # Gérer la valeur vide pour date_livraison
                if date_livraison:
                    date_livraison = datetime.strptime(date_livraison, '%Y-%m-%dT%H:%M')
                    cursor.execute(
                    "UPDATE commandes SET statut_commande = %s, date_livraison = %s, updatedAt = %s WHERE id = %s",
                    (statut_commande, date_livraison, now, order_id)
                )
                else:
                    date_livraison = None
                    cursor.execute(
                        "UPDATE commandes SET statut_commande = %s, updatedAt = %s WHERE id = %s",
                        (statut_commande, now, order_id)
                    )

                conn.commit()
                flash('Commande mise à jour avec succès.', 'success')

            # Supprimer une commande
            if 'delete_order' in request.form:
                order_id = request.form['order_id']
                cursor.execute("DELETE FROM commandes WHERE id = %s", (order_id,))
                conn.commit()
                flash('Commande supprimée avec succès.', 'success')

        cursor.execute("SELECT * FROM commandes")
        orders = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('admin_dashboard.html', section='orders', orders=orders)
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))

@app.route('/admin/payments', methods=['GET', 'POST'])
def manage_payments():
    if 'role' in session and session['role'] in ['admin', 'gestionnaire']:
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor(dictionary=True)

        if request.method == 'POST':
            # Modifier un paiement existant
            if 'update_payment' in request.form:
                payment_id = request.form['payment_id']
                method_paiement = request.form['method_paiement']
                now = datetime.now()

                cursor.execute(
                    "UPDATE paiements SET method_paiement = %s, updatedAt = %s WHERE id = %s",
                    (method_paiement, now, payment_id)
                )
                conn.commit()
                flash('Paiement mis à jour avec succès.', 'success')

            # Supprimer un paiement
            if 'delete_payment' in request.form:
                payment_id = request.form['payment_id']
                cursor.execute("DELETE FROM paiements WHERE id = %s", (payment_id,))
                conn.commit()
                flash('Paiement supprimé avec succès.', 'success')

        cursor.execute("SELECT * FROM paiements")
        payments = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('admin_dashboard.html', section='payments', payments=payments)
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))

@app.route('/admin/invoices', methods=['GET', 'POST'])
def manage_invoices():
    if 'role' in session and session['role'] in ['admin', 'gestionnaire']:
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor(dictionary=True)

        if request.method == 'POST':
            # Modifier une facture existante
            if 'update_invoice' in request.form:
                invoice_id = request.form['invoice_id']
                total_facture = request.form['total_facture']
                now = datetime.now()

                cursor.execute(
                    "UPDATE factures SET total_facture = %s, updatedAt = %s WHERE id = %s",
                    (total_facture, now, invoice_id)
                )
                conn.commit()
                flash('Facture mise à jour avec succès.', 'success')

            # Supprimer une facture
            if 'delete_invoice' in request.form:
                invoice_id = request.form['invoice_id']
                cursor.execute("DELETE FROM factures WHERE id = %s", (invoice_id,))
                conn.commit()
                flash('Facture supprimée avec succès.', 'success')

        cursor.execute("SELECT * FROM factures")
        invoices = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('admin_dashboard.html', section='invoices', invoices=invoices)
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))


@app.route('/manager/clients', methods=['GET', 'POST'])
def manage_clients_manager():
    if 'role' in session and session['role'] == 'gestionnaire':
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor(dictionary=True)

        if request.method == 'POST':
            # Ajouter un nouveau client
            if 'add_client' in request.form:
                username = request.form['username']
                email = request.form['email']
                password = request.form['password']
                hashed_password = hashlib.sha256(password.encode()).hexdigest()
                now = datetime.now()

                cursor.execute(
                    "INSERT INTO users (username, email, password, role, createdAt, updatedAt) VALUES (%s, %s, %s, %s, %s, %s)",
                    (username, email, hashed_password, 'client', now, now)
                )
                conn.commit()
                flash('Client ajouté avec succès.', 'success')

            # Modifier un client existant
            if 'update_client' in request.form:
                client_id = request.form['client_id']
                email = request.form['email']
                now = datetime.now()

                cursor.execute(
                    "UPDATE users SET email = %s, updatedAt = %s WHERE id = %s AND role = 'client'",
                    (email, now, client_id)
                )
                conn.commit()
                flash('Client mis à jour avec succès.', 'success')

            # Supprimer un client
            if 'delete_client' in request.form:
                client_id = request.form['client_id']
                cursor.execute("DELETE FROM users WHERE id = %s AND role = 'client'", (client_id,))
                conn.commit()
                flash('Client supprimé avec succès.', 'success')

        cursor.execute("SELECT id, username, email FROM users WHERE role = 'client'")
        clients = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('manager_dashboard.html', section='clients', clients=clients)
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))

@app.route('/manager/products', methods=['GET', 'POST'])
def manage_products_manager():
    if 'role' in session and session['role'] == 'gestionnaire':
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor(dictionary=True)

        if request.method == 'POST':
            # Ajouter un nouveau produit
            if 'add_product' in request.form:
                nom = request.form['nom']
                prix = request.form['prix']
                marque = request.form['marque']
                specifications = request.form['specifications']
                quantiteStock = request.form['quantiteStock']
                now = datetime.now()

                cursor.execute(
                    "INSERT INTO products (nom, prix, marque, specifications, quantiteStock, createdAt, updatedAt) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                    (nom, prix, marque, specifications, quantiteStock, now, now)
                )
                conn.commit()
                flash('Produit ajouté avec succès.', 'success')

            # Modifier un produit existant
            if 'update_product' in request.form:
                product_id = request.form['product_id']
                nom = request.form['nom']
                prix = request.form['prix']
                marque = request.form['marque']
                specifications = request.form['specifications']
                quantiteStock = request.form['quantiteStock']
                now = datetime.now()

                cursor.execute(
                    "UPDATE products SET nom = %s, prix = %s, marque = %s, specifications = %s, quantiteStock = %s, updatedAt = %s WHERE id = %s",
                    (nom, prix, marque, specifications, quantiteStock, now, product_id)
                )
                conn.commit()
                flash('Produit mis à jour avec succès.', 'success')

            # Supprimer un produit
            if 'delete_product' in request.form:
                product_id = request.form['product_id']
                cursor.execute("DELETE FROM products WHERE id = %s", (product_id,))
                conn.commit()
                flash('Produit supprimé avec succès.', 'success')

        cursor.execute("SELECT * FROM products")
        products = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('manager_dashboard.html', section='products', products=products)
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))

@app.route('/manager/orders', methods=['GET', 'POST'])
def manage_orders_manager():
    if 'role' in session and session['role'] in ['admin', 'gestionnaire']:
        conn = mysql.connector.connect(**config)
        cursor = conn.cursor(dictionary=True)

        if request.method == 'POST':
            # Modifier une commande existante
            if 'update_order' in request.form:
                order_id = request.form['order_id']
                statut_commande = request.form['statut_commande']
                date_livraison = request.form['date_livraison']
                now = datetime.now()

               # Gérer la valeur vide pour date_livraison
                if date_livraison:
                    date_livraison = datetime.strptime(date_livraison, '%Y-%m-%dT%H:%M')
                    cursor.execute(
                    "UPDATE commandes SET statut_commande = %s, date_livraison = %s, updatedAt = %s WHERE id = %s",
                    (statut_commande, date_livraison, now, order_id)
                )
                else:
                    date_livraison = None
                    cursor.execute(
                        "UPDATE commandes SET statut_commande = %s, updatedAt = %s WHERE id = %s",
                        (statut_commande, now, order_id)
                    )
                conn.commit()
                flash('Commande mise à jour avec succès.', 'success')

            # Supprimer une commande
            if 'delete_order' in request.form:
                order_id = request.form['order_id']
                cursor.execute("DELETE FROM commandes WHERE id = %s", (order_id,))
                conn.commit()
                flash('Commande supprimée avec succès.', 'success')

        cursor.execute("SELECT * FROM commandes")
        orders = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('manager_dashboard.html', section='orders', orders=orders)
    else:
        flash('Accès refusé.', 'danger')
        return redirect(url_for('home'))


@app.route('/catalogue', methods=['GET', 'POST'])
def catalogue():
    min_price = request.args.get('min_price', type=float)
    max_price = request.args.get('max_price', type=float)
    marque = request.args.get('marque')

    query = "SELECT * FROM products WHERE 1=1"
    params = []

    if min_price is not None:
        query += " AND prix >= %s"
        params.append(min_price)
    
    if max_price is not None:
        query += " AND prix <= %s"
        params.append(max_price)
    
    if marque:
        query += " AND marque = %s"
        params.append(marque)
    
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, params)
    products = cursor.fetchall()
    cursor.close()
    conn.close()

    cart = session.get('cart', {})

    return render_template('catalogue.html', products=products, cart=cart)

@app.route('/sales_report', methods=['GET'])
def sales_report():
    if 'username' not in session or session.get('role') != 'admin':
        flash('Accès refusé. Vous devez être connecté en tant qu\'admin pour accéder à cette page.', 'danger')
        return redirect(url_for('connexion'))

    year = request.args.get('year', type=int)
    if not year:
        flash('Veuillez entrer une année valide.', 'danger')
        return redirect(url_for('admin_dashboard'))

    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)

    # Calculer le chiffre d'affaires annuel
    cursor.execute("""
        SELECT SUM(total_commande) AS annual_sales
        FROM commandes
       WHERE YEAR(createdAt) = %s AND LOWER(statut_commande) IN ('payee', 'Livree')
    """, (year,))
    annual_sales = cursor.fetchone()['annual_sales'] or 0

    # Calculer le chiffre d'affaires mensuel
    cursor.execute("""
        SELECT MONTH(createdAt) AS month, SUM(total_commande) AS monthly_sales
        FROM commandes
        WHERE YEAR(createdAt) = %s AND LOWER(statut_commande) IN ('payee', 'Livree')
        GROUP BY MONTH(createdAt)
    """, (year,))
    monthly_sales = cursor.fetchall()

    cursor.close()
    conn.close()

    # Organiser les ventes mensuelles dans un dictionnaire
    monthly_sales_dict = {month['month']: month['monthly_sales'] for month in monthly_sales}

    # Dictionnaire de correspondance des mois
    month_names = {
        1: 'Janvier', 2: 'Février', 3: 'Mars', 4: 'Avril',
        5: 'Mai', 6: 'Juin', 7: 'Juillet', 8: 'Août',
        9: 'Septembre', 10: 'Octobre', 11: 'Novembre', 12: 'Décembre'
    }

    sales_report = {
        'year': year,
        'annual_sales': annual_sales,
        'monthly_sales': {month_names[k]: v for k, v in monthly_sales_dict.items()}
    }

    return render_template('admin_dashboard.html', sales_report=sales_report, section=None)

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    if 'username' not in session:
        flash('Vous devez être connecté pour ajouter des produits au panier.', 'danger')
        return redirect(url_for('connexion'))

    product_id = request.form.get('product_id')
    product_id = str(product_id)
    cart = session.get('cart', {})

    # Connect to the database and fetch product details
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM products WHERE id = %s", (product_id,))
    product = cursor.fetchone()
    cursor.close()
    conn.close()

    if not product:
        flash('Produit non trouvé.', 'danger')
        return redirect(url_for('catalogue'))

    if product_id in cart:
        cart[product_id]['quantity'] += 1
    else:
        cart[product_id] = {'quantity': 1, 'product': product}
    
    session['cart'] = cart
    flash('Produit ajouté au panier.', 'success')
    return redirect(url_for('catalogue'))

@app.route('/remove_from_cart', methods=['POST'])
def remove_from_cart():
    product_id = request.form.get('product_id')
    cart = session.get('cart', {})
    if product_id in cart:
        del cart[product_id]
        session['cart'] = cart
        flash('Produit retiré du panier.', 'success')
    return redirect(url_for('cart'))


@app.route('/cart')
def cart():
    cart = session.get('cart', {})
    product_ids = list(cart.keys())
    if product_ids:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        query = "SELECT * FROM products WHERE id IN (%s)" % ','.join(['%s'] * len(product_ids))
        cursor.execute(query, product_ids)
        products = cursor.fetchall()
        cursor.close()
        conn.close()
        
        for product in products:
            cart[str(product['id'])]['product'] = product
            cart[str(product['id'])]['total'] = product['prix'] * cart[str(product['id'])]['quantity']
            
        # Convert cart items from string keys to int keys to avoid potential issues in templates
        cart = {int(k): v for k, v in cart.items()}
    
    return render_template('cart.html', cart=cart)

@app.route('/update_cart', methods=['POST'])
def update_cart():
    product_id = request.form.get('product_id')
    quantity = int(request.form.get('quantity'))
    cart = session.get('cart', {})
    if product_id in cart:
        cart[product_id]['quantity'] = quantity
        session['cart'] = cart
        flash('Quantité mise à jour.', 'success')
    return redirect(url_for('cart'))

@app.route('/clear_cart', methods=['POST'])
def clear_cart():
    session.pop('cart', None)
    flash('Panier vidé.', 'success')
    return redirect(url_for('cart'))

@app.route('/validate_order', methods=['POST'])
def validate_order():
    if 'username' not in session:
        flash('Vous devez être connecté pour valider une commande.', 'danger')
        return redirect(url_for('connexion'))

    user_id = session.get('user_id')
    if not user_id:
        flash('Erreur: Impossible de récupérer les informations utilisateur.', 'danger')
        return redirect(url_for('cart'))

    cart = session.get('cart', {})
    if not cart:
        flash('Votre panier est vide.', 'danger')
        return redirect(url_for('catalogue'))

    total_commande = sum(item['quantity'] * item['product']['prix'] for item in cart.values())
    now = datetime.now()

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO commandes (total_commande, statut_commande, createdAt, updatedAt, id_user) VALUES (%s, %s, %s, %s, %s)",
        (total_commande, 'En attente', now, now, user_id)
    )
    commande_id = cursor.lastrowid

    for item in cart.values():
        cursor.execute(
            "INSERT INTO ligne_commandes (quantite, prix, id_product, id_commande, createdAt, updatedAt) VALUES (%s, %s, %s, %s, %s, %s)",
            (item['quantity'], item['product']['prix'], item['product']['id'], commande_id, now, now)
        )

    conn.commit()
    cursor.close()
    conn.close()
    
    session.pop('cart', None)
    flash('Commande validée. Vous pouvez procéder au paiement.', 'success')
    return redirect(url_for('payment', commande_id=commande_id))

@app.route('/pay', methods=['POST'])
def pay():
    commande_id = request.form.get('commande_id')
    method_paiement = request.form.get('method_paiement')

    conn = get_db_connection()
    cursor = conn.cursor()
    now = datetime.now()
    cursor.execute("INSERT INTO paiements (id_commande, method_paiement, createdAt, updatedAt) VALUES (%s, %s, %s, %s)",
                   (commande_id, method_paiement, now, now))
    paiement_id = cursor.lastrowid

    cursor.execute("INSERT INTO factures (total_facture, createdAt, updatedAt, id_user, id_paiement) SELECT total_commande, %s, %s, id_user, %s FROM commandes WHERE id = %s",
                   (now, now, paiement_id, commande_id))
    
    cursor.execute("UPDATE commandes SET statut_commande = 'Payé' WHERE id = %s", (commande_id,))
    conn.commit()
    cursor.close()
    conn.close()
    flash('Paiement effectué et facture créée.', 'success')
    return redirect(url_for('home'))

@app.route('/process_payment/<int:commande_id>', methods=['POST'])
def process_payment(commande_id):
    if 'username' not in session:
        flash('Vous devez être connecté pour effectuer un paiement.', 'danger')
        return redirect(url_for('connexion'))

    method_paiement = request.form.get('method_paiement')
    user_id = session.get('user_id')
    now = datetime.now()

    # Ajout de logs pour le débogage
    print(f"Processing payment for commande_id: {commande_id}, method_paiement: {method_paiement}, user_id: {user_id}")

    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)
    try:
        # Récupérer le montant total de la commande
        cursor.execute("SELECT total_commande FROM commandes WHERE id = %s", (commande_id,))
        commande = cursor.fetchone()
        if not commande:
            flash('Commande non trouvée.', 'danger')
            return redirect(url_for('home'))

        total_commande = commande['total_commande']
        
        # Récupérer les produits de la commande
        cursor.execute("SELECT id_product, quantite FROM ligne_commandes WHERE id_commande = %s", (commande_id,))
        ligne_commandes = cursor.fetchall()

        # Mettre à jour le stock pour chaque produit
        for ligne in ligne_commandes:
            product_id = ligne['id_product']
            quantite = ligne['quantite']
            cursor.execute(
                "UPDATE products SET quantiteStock = quantiteStock - %s WHERE id = %s",
                (quantite, product_id)
            )
            
        # Insérer l'enregistrement de paiement dans la base de données
        cursor.execute(
            "INSERT INTO paiements (id_commande, method_paiement, createdAt, updatedAt) VALUES (%s, %s, %s, %s)",
            (commande_id, method_paiement, now, now)
        )
        paiement_id = cursor.lastrowid

        # Insérer l'enregistrement de facture dans la base de données
        cursor.execute(
            "INSERT INTO factures (total_facture, createdAt, updatedAt, id_user, id_paiement) VALUES (%s, %s, %s, %s, %s)",
            (total_commande, now, now, user_id, paiement_id)
        )

        # Mettre à jour le statut de la commande à 'Payé'
        statut_paye = 'Payee'  # Assurez-vous que c'est bien une des valeurs définies dans votre base de données
        cursor.execute(
            "UPDATE commandes SET statut_commande = %s, updatedAt = %s WHERE id = %s",
            (statut_paye, now, commande_id)
        )

        conn.commit()
        flash('Paiement effectué avec succès. Votre commande est maintenant payée.', 'success')
    except mysql.connector.Error as err:
        error_message = f"Something went wrong: {err}"
        print(error_message)  # Log the error
        conn.rollback()
        flash(f'Erreur lors du traitement du paiement: {error_message}', 'danger')
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for('home'))

@app.route('/payment/<int:commande_id>')
def payment(commande_id):
    if 'username' not in session:
        flash('Vous devez être connecté pour accéder à cette page.', 'danger')
        return redirect(url_for('connexion'))

    return render_template('payment.html', commande_id=commande_id)

@app.route('/client_orders')
def client_orders():
    if 'username' not in session or session.get('role') != 'client':
        flash('Vous devez être connecté en tant que client pour consulter vos commandes.', 'danger')
        return redirect(url_for('connexion'))

    user_id = session.get('user_id')
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM commandes WHERE id_user = %s", (user_id,))
    orders = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('client_orders.html', orders=orders)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
